# Ubicación en tiempo real — arquitectura preparada

## Ciclo móvil
- Conductor: obtiene GPS y publica `POST /api/driver/location` cada 4 segundos.
- Técnico: obtiene GPS y publica `POST /api/technician/location` cada 4 segundos.
- Técnico: refresca asistencias/ubicaciones de conductores cada 4 segundos.
- Conductor: refresca el dashboard/asistencia cada 4 segundos para recibir la ubicación del técnico.
- El backend debe distribuir/guardar estas posiciones para que el gestor pueda consultar ambas.

## Contrato de datos de ubicación
Los POST de ubicación envían:
- `latitude`
- `longitude`
- `accuracy_m`
- `updated_at` (epoch milliseconds)
- `assistance_id` cuando existe una asistencia activa.

## Importante
La pantalla del gestor no está incluida en estos dos proyectos móviles. Su APK/web debe consumir el backend y mostrar simultáneamente conductores y técnicos.
