 package com.asistencias.tecnico

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.animation.core.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors


private const val API_BASE_URL = "http://192.168.1.215:3000"


private val NeonBlue = Color(0xFF1687FF)
private val NeonCyan = Color(0xFF00D9FF)
private val DeepNavy = Color(0xFF06111F)
private val Navy = Color(0xFF0A1B2E)
private val NavyCard = Color(0xFF10263D)
private val NavyCard2 = Color(0xFF132D47)
private val TextMain = Color(0xFFF4F9FF)
private val TextSoft = Color(0xFF9DB2C8)
private val TechGreen = Color(0xFF19D68A)
private val TechRed = Color(0xFFFF5C6C)
private val TechOrange = Color(0xFFFFA43B)
private val LineBlue = Color(0xFF23496C)
private val TechBlue = NeonBlue
private val TechCyan = NeonCyan
private val TechBlueDark = DeepNavy
private val TechDark = DeepNavy
private val TechBlueLight = Color(0xFF4DA6FF)
private val NeonBlueLight = Color(0xFF4DA6FF)


@Composable
fun TechnicianTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = NeonBlue,
        onPrimary = Color.White,
        primaryContainer = NavyCard2,
        onPrimaryContainer = TextMain,
        secondary = NeonCyan,
        onSecondary = DeepNavy,
        secondaryContainer = NavyCard,
        onSecondaryContainer = TextMain,
        background = DeepNavy,
        onBackground = TextMain,
        surface = NavyCard,
        onSurface = TextMain,
        surfaceVariant = NavyCard2,
        onSurfaceVariant = TextSoft,
        error = TechRed,
        onError = Color.White
    )
    MaterialTheme(
        colorScheme = colors,
        shapes = MaterialTheme.shapes.copy(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(26.dp)
        ),
        content = content
    )
}

@Composable
fun AppMark(size: androidx.compose.ui.unit.Dp = 52.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(
            brush = Brush.linearGradient(listOf(TechBlueDark, TechBlue, TechCyan)),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(18.dp.toPx())
        )
        drawLine(Color.White, androidx.compose.ui.geometry.Offset(w*.20f,h*.66f), androidx.compose.ui.geometry.Offset(w*.40f,h*.46f), 5f)
        drawLine(Color.White, androidx.compose.ui.geometry.Offset(w*.40f,h*.46f), androidx.compose.ui.geometry.Offset(w*.58f,h*.58f), 5f)
        drawLine(Color.White, androidx.compose.ui.geometry.Offset(w*.58f,h*.58f), androidx.compose.ui.geometry.Offset(w*.82f,h*.25f), 5f)
        drawCircle(Color.White, 4.5f, androidx.compose.ui.geometry.Offset(w*.20f,h*.66f))
        drawCircle(Color.White, 4.5f, androidx.compose.ui.geometry.Offset(w*.82f,h*.25f))
    }
}

@Composable
fun ResourceIcon(title: String, modifier: Modifier = Modifier) {
    /*
     * ================================================================
     * ICONOS EDITABLES POR IMAGEN
     * ================================================================
     *
     * Puedes cambiar CUALQUIER icono sin modificar este archivo.
     *
     * En Android Studio ve a:
     * app > src > main > res > drawable
     *
     * Usa exactamente estos nombres para las imágenes:
     *   ic_escalera_tijera.png
     *   ic_escalera_extension.png
     *   ic_ambas.png
     *   ic_taladro.png
     *   ic_portatil.png
     *   ic_auxiliar_sena.png
     *   ic_herramientas.png
     *   ic_otras.png
     *
     * Para cambiar un icono solo reemplaza la imagen por otra con el
     * mismo nombre. NO necesitas tocar el código.
     *
     * Si todavía no existe la imagen, se usa automáticamente el icono
     * dibujado en Kotlin como respaldo. Así el proyecto sigue compilando.
     */
    val context = LocalContext.current

    // "Ambas" se arma directamente con las dos imágenes de escaleras.
    if (title == "Ambas") {
        Row(
            modifier = modifier,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ResourceImageByName("ic_escalera_tijera", "Escalera de tijera", Modifier.weight(1f).fillMaxHeight())
            ResourceImageByName("ic_escalera_extension", "Escalera de extensión", Modifier.weight(1f).fillMaxHeight())
        }
        return
    }

    val drawableName = when (title) {
        "Escalera de tijera" -> "ic_escalera_tijera"
        "Escalera de extensión" -> "ic_escalera_extension"
        "Taladro" -> "ic_taladro"
        "Portátil" -> "ic_portatil"
        "Auxiliar SENA", "Apoyo técnico" -> "ic_auxiliar_sena"
        "Herramientas" -> "ic_herramientas"
        "Otras" -> "ic_otras"
        else -> null
    }

    if (drawableName != null) {
        val drawableId = context.resources.getIdentifier(drawableName, "drawable", context.packageName)
        if (drawableId != 0) {
            Image(
                painter = painterResource(id = drawableId),
                contentDescription = title,
                contentScale = ContentScale.Fit,
                modifier = modifier
            )
            return
        }
    }

    ResourceIconCanvas(title, modifier)
}

@Composable
private fun ResourceImageByName(name: String, description: String, modifier: Modifier) {
    val context = LocalContext.current
    val id = context.resources.getIdentifier(name, "drawable", context.packageName)
    if (id != 0) {
        Image(
            painter = painterResource(id = id),
            contentDescription = description,
            contentScale = ContentScale.Fit,
            modifier = modifier
        )
    }
}

@Composable
private fun ResourceIconCanvas(title: String, modifier: Modifier = Modifier) {
    /*
     * ICONOS DIBUJADOS DIRECTAMENTE EN KOTLIN.
     * Estilo: ilustración realista simplificada, con volumen, sombras,
     * aluminio, azul/cian y detalles amarillos. No usa PNG, JPG ni XML.
     *
     * Para editar un icono:
     * Ctrl + F -> "ICONO: Escalera de tijera"
     * Ctrl + F -> "ICONO: Escalera de extensión"
     * Ctrl + F -> "ICONO: Ambas"
     * Ctrl + F -> "ICONO: Taladro"
     * Ctrl + F -> "ICONO: Portátil"
     * Ctrl + F -> "ICONO: Apoyo técnico"
     * Ctrl + F -> "ICONO: Herramientas / Otras"
     */
    Canvas(modifier) {
        val w = size.width
        val h = size.height

        val blue = TechBlue
        val blueDark = TechBlueDark
        val cyan = TechCyan
        val aluminum = Color(0xFFD9E1E7)
        val aluminumLight = Color(0xFFF1F4F6)
        val aluminumDark = Color(0xFF7A8992)
        val steel = Color(0xFF52636D)
        val dark = Color(0xFF26343D)
        val dark2 = Color(0xFF3B4A53)
        val shadow = Color(0x26000000)
        val yellow = Color(0xFFFFC107)
        val yellowDark = Color(0xFFE09A00)
        val skin = Color(0xFFD69A72)
        val skinDark = Color(0xFF9F684A)

        fun rr(color: Color, l: Float, t: Float, r: Float, b: Float, radius: Float) {
            drawRoundRect(
                color = color,
                topLeft = androidx.compose.ui.geometry.Offset(l, t),
                size = androidx.compose.ui.geometry.Size(r - l, b - t),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
            )
        }

        fun line(color: Color, x1: Float, y1: Float, x2: Float, y2: Float, width: Float) {
            drawLine(
                color = color,
                start = androidx.compose.ui.geometry.Offset(x1, y1),
                end = androidx.compose.ui.geometry.Offset(x2, y2),
                strokeWidth = width,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }

        fun circle(color: Color, radius: Float, x: Float, y: Float) {
            drawCircle(color = color, radius = radius, center = androidx.compose.ui.geometry.Offset(x, y))
        }

        fun ground() {
            drawOval(
                color = shadow,
                topLeft = androidx.compose.ui.geometry.Offset(w * .10f, h * .84f),
                size = androidx.compose.ui.geometry.Size(w * .80f, h * .08f)
            )
        }

        when (title) {
            // ============================================================
            // ICONO: Escalera de tijera
            // ============================================================
            "Escalera de tijera" -> {
                ground()

                // Patas posteriores: sombra y cuerpo de aluminio.
                line(aluminumDark, w*.57f, h*.20f, w*.77f, h*.83f, w*.080f)
                line(aluminum,     w*.55f, h*.20f, w*.75f, h*.82f, w*.052f)
                line(Color.White.copy(alpha=.65f), w*.56f, h*.24f, w*.70f, h*.68f, w*.012f)

                // Patas delanteras.
                line(aluminumDark, w*.43f, h*.20f, w*.22f, h*.84f, w*.080f)
                line(aluminum,     w*.45f, h*.20f, w*.24f, h*.83f, w*.052f)
                line(Color.White.copy(alpha=.65f), w*.44f, h*.24f, w*.30f, h*.68f, w*.012f)

                // Refuerzos laterales.
                line(steel, w*.28f, h*.52f, w*.68f, h*.52f, w*.020f)
                line(steel, w*.31f, h*.68f, w*.71f, h*.68f, w*.018f)

                // Plataforma superior.
                rr(blueDark, w*.31f, h*.13f, w*.69f, h*.22f, w*.030f)
                rr(blue,     w*.34f, h*.115f, w*.66f, h*.19f, w*.022f)
                rr(cyan,     w*.42f, h*.14f, w*.58f, h*.17f, w*.010f)

                // Bisagras.
                circle(blueDark, w*.035f, w*.43f, h*.21f)
                circle(blue,     w*.022f, w*.43f, h*.21f)
                circle(blueDark, w*.035f, w*.57f, h*.21f)
                circle(blue,     w*.022f, w*.57f, h*.21f)

                // Peldaños con doble capa para aspecto metálico.
                for (i in 0..4) {
                    val y = h * (.31f + i*.115f)
                    val inset = i * w * .010f
                    line(blueDark, w*.30f-inset, y, w*.70f+inset, y, w*.055f)
                    line(Color(0xFF65B5E8), w*.33f-inset, y-w*.009f, w*.67f+inset, y-w*.009f, w*.018f)
                }

                // Zapatas de goma.
                rr(blueDark, w*.13f, h*.82f, w*.31f, h*.91f, w*.026f)
                rr(blueDark, w*.69f, h*.82f, w*.87f, h*.91f, w*.026f)
                rr(cyan, w*.17f, h*.83f, w*.27f, h*.865f, w*.012f)
                rr(cyan, w*.73f, h*.83f, w*.83f, h*.865f, w*.012f)
            }

            // ============================================================
            // ICONO: Escalera de extensión
            // ============================================================
            "Escalera de extensión" -> {
                ground()

                // Escalera apoyada, con dos rieles de aluminio.
                line(aluminumDark, w*.29f, h*.86f, w*.43f, h*.15f, w*.078f)
                line(aluminum,     w*.31f, h*.84f, w*.45f, h*.16f, w*.050f)
                line(Color.White.copy(alpha=.65f), w*.33f, h*.78f, w*.43f, h*.28f, w*.012f)

                line(aluminumDark, w*.67f, h*.86f, w*.56f, h*.15f, w*.078f)
                line(aluminum,     w*.65f, h*.84f, w*.54f, h*.16f, w*.050f)
                line(Color.White.copy(alpha=.65f), w*.63f, h*.78f, w*.55f, h*.28f, w*.012f)

                // Sección telescópica que sobresale.
                line(aluminumDark, w*.47f, h*.66f, w*.58f, h*.09f, w*.060f)
                line(aluminum,     w*.49f, h*.64f, w*.60f, h*.10f, w*.039f)
                line(aluminumDark, w*.76f, h*.66f, w*.67f, h*.09f, w*.060f)
                line(aluminum,     w*.74f, h*.64f, w*.65f, h*.10f, w*.039f)

                // Peldaños inferiores.
                for (i in 0..5) {
                    val y = h*(.29f+i*.105f)
                    val left = w*(.37f-i*.004f)
                    val right = w*(.67f+i*.004f)
                    line(blueDark, left, y, right, y, w*.047f)
                    line(Color(0xFF65B5E8), left+w*.025f, y-w*.007f, right-w*.025f, y-w*.007f, w*.015f)
                }

                // Peldaños de la sección superior.
                for (i in 0..4) {
                    val y = h*(.20f+i*.105f)
                    val left = w*(.56f+i*.012f)
                    val right = w*(.70f+i*.008f)
                    line(blueDark, left, y, right, y, w*.042f)
                    line(Color(0xFF65B5E8), left+w*.018f, y-w*.006f, right-w*.018f, y-w*.006f, w*.013f)
                }

                // Seguros y herrajes amarillos.
                rr(blueDark, w*.39f, h*.075f, w*.51f, h*.17f, w*.018f)
                rr(blue,     w*.41f, h*.075f, w*.49f, h*.135f, w*.012f)
                rr(yellowDark, w*.56f, h*.39f, w*.63f, h*.47f, w*.014f)
                rr(yellow,     w*.575f, h*.395f, w*.615f, h*.445f, w*.010f)

                // Zapatas.
                rr(blueDark, w*.23f, h*.82f, w*.42f, h*.91f, w*.026f)
                rr(blueDark, w*.68f, h*.82f, w*.87f, h*.91f, w*.026f)
                rr(cyan, w*.27f, h*.83f, w*.37f, h*.865f, w*.012f)
                rr(cyan, w*.72f, h*.83f, w*.82f, h*.865f, w*.012f)
            }

            // ============================================================
            // ICONO: Ambas
            // ============================================================
            "Ambas" -> {
                ground()

                // Tijera izquierda.
                line(aluminumDark, w*.30f, h*.20f, w*.14f, h*.84f, w*.066f)
                line(aluminum,     w*.31f, h*.20f, w*.16f, h*.83f, w*.044f)
                line(aluminumDark, w*.45f, h*.20f, w*.58f, h*.84f, w*.066f)
                line(aluminum,     w*.44f, h*.20f, w*.56f, h*.83f, w*.044f)
                rr(blueDark, w*.22f, h*.14f, w*.41f, h*.23f, w*.018f)
                rr(blue, w*.25f, h*.14f, w*.38f, h*.19f, w*.010f)

                for (i in 0..4) {
                    val y=h*(.31f+i*.12f)
                    line(blueDark, w*(.22f-i*.004f), y, w*(.49f+i*.010f), y, w*.045f)
                    line(Color(0xFF65B5E8), w*(.25f-i*.004f), y-w*.006f, w*(.46f+i*.010f), y-w*.006f, w*.014f)
                }

                // Extensión derecha.
                line(aluminumDark, w*.57f, h*.88f, w*.68f, h*.12f, w*.060f)
                line(aluminum,     w*.59f, h*.86f, w*.69f, h*.13f, w*.041f)
                line(aluminumDark, w*.82f, h*.88f, w*.71f, h*.12f, w*.060f)
                line(aluminum,     w*.80f, h*.86f, w*.72f, h*.13f, w*.041f)
                for (i in 0..5) {
                    val y=h*(.24f+i*.105f)
                    line(blueDark,w*.64f,y,w*.79f,y,w*.040f)
                    line(Color(0xFF65B5E8),w*.66f,y-w*.006f,w*.77f,y-w*.006f,w*.013f)
                }
                rr(blueDark,w*.62f,h*.07f,w*.77f,h*.16f,w*.018f)
                rr(yellowDark,w*.63f,h*.38f,w*.70f,h*.46f,w*.014f)
                rr(yellow,w*.642f,h*.39f,w*.688f,h*.44f,w*.009f)
                rr(blueDark,w*.50f,h*.82f,w*.67f,h*.91f,w*.022f)
                rr(blueDark,w*.76f,h*.82f,w*.90f,h*.91f,w*.022f)
            }

            // ============================================================
            // ICONO: Taladro
            // ============================================================
            "Taladro" -> {
                ground()
                rr(dark, w*.14f,h*.25f,w*.70f,h*.56f,w*.075f)
                rr(dark2,w*.17f,h*.24f,w*.67f,h*.52f,w*.060f)
                rr(blueDark,w*.20f,h*.27f,w*.56f,h*.48f,w*.050f)
                rr(blue,w*.22f,h*.28f,w*.54f,h*.45f,w*.040f)
                rr(cyan,w*.25f,h*.30f,w*.42f,h*.34f,w*.012f)
                rr(dark,w*.52f,h*.24f,w*.73f,h*.48f,w*.070f)
                rr(dark2,w*.55f,h*.27f,w*.70f,h*.45f,w*.050f)
                line(Color(0xFF64747E),w*.59f,h*.30f,w*.59f,h*.42f,w*.014f)
                line(Color(0xFF64747E),w*.64f,h*.30f,w*.64f,h*.42f,w*.014f)
                rr(dark,w*.68f,h*.33f,w*.84f,h*.45f,w*.035f)
                rr(aluminumDark,w*.70f,h*.35f,w*.84f,h*.43f,w*.024f)
                line(Color.White,w*.73f,h*.36f,w*.73f,h*.42f,w*.010f)
                line(Color.White,w*.77f,h*.36f,w*.77f,h*.42f,w*.010f)
                line(Color.White,w*.81f,h*.36f,w*.81f,h*.42f,w*.010f)
                line(aluminumDark,w*.83f,h*.39f,w*.96f,h*.39f,w*.025f)
                line(Color.White,w*.84f,h*.385f,w*.95f,h*.385f,w*.009f)
                line(aluminumDark,w*.95f,h*.39f,w*.985f,h*.39f,w*.010f)
                val grip=Path().apply{moveTo(w*.38f,h*.47f);lineTo(w*.54f,h*.47f);lineTo(w*.57f,h*.76f);lineTo(w*.50f,h*.86f);lineTo(w*.39f,h*.78f);close()}
                drawPath(grip,dark)
                rr(dark2,w*.42f,h*.51f,w*.54f,h*.77f,w*.032f)
                rr(blue,w*.45f,h*.54f,w*.51f,h*.62f,w*.018f)
                rr(yellowDark,w*.35f,h*.47f,w*.44f,h*.55f,w*.018f)
                rr(dark,w*.37f,h*.75f,w*.59f,h*.91f,w*.040f)
                rr(blueDark,w*.40f,h*.76f,w*.56f,h*.84f,w*.022f)
                rr(cyan,w*.43f,h*.78f,w*.53f,h*.82f,w*.012f)
                circle(Color.White.copy(alpha=.55f),w*.025f,w*.27f,h*.34f)
            }

            // ============================================================
            // ICONO: Portátil
            // ============================================================
            "Portátil" -> {
                ground()
                rr(dark,w*.10f,h*.11f,w*.90f,h*.68f,w*.050f)
                rr(aluminumDark,w*.13f,h*.14f,w*.87f,h*.65f,w*.032f)
                rr(blueDark,w*.17f,h*.18f,w*.83f,h*.61f,w*.020f)
                drawRect(
                    brush=Brush.linearGradient(listOf(Color(0xFFBDEEFF),Color(0xFF2D8DCA))),
                    topLeft=androidx.compose.ui.geometry.Offset(w*.18f,h*.19f),
                    size=androidx.compose.ui.geometry.Size(w*.64f,h*.41f)
                )
                val shine=Path().apply{moveTo(w*.18f,h*.19f);lineTo(w*.46f,h*.19f);lineTo(w*.18f,h*.47f);close()}
                drawPath(shine,Color.White.copy(alpha=.18f))
                circle(Color(0xFF18252D),w*.010f,w*.50f,h*.145f)
                rr(aluminumDark,w*.38f,h*.63f,w*.62f,h*.69f,w*.014f)
                val base=Path().apply{moveTo(w*.10f,h*.68f);lineTo(w*.90f,h*.68f);lineTo(w*.98f,h*.81f);quadraticTo(w*.50f,h*.89f,w*.02f,h*.81f);close()}
                drawPath(base,aluminumDark)
                val top=Path().apply{moveTo(w*.13f,h*.69f);lineTo(w*.87f,h*.69f);lineTo(w*.92f,h*.79f);quadraticTo(w*.50f,h*.84f,w*.08f,h*.79f);close()}
                drawPath(top,aluminumLight)
                for(row in 0..2){
                    val y=h*(.715f+row*.038f)
                    for(col in 0..7){
                        val x=w*(.22f+col*.071f)
                        rr(Color(0xFF87959E),x,y,x+w*.045f,y+h*.020f,w*.005f)
                    }
                }
                rr(Color(0xFFABB7BD),w*.43f,h*.825f,w*.57f,h*.84f,w*.006f)
                rr(blue,w*.44f,h*.695f,w*.56f,h*.708f,w*.006f)
            }

            // ============================================================
            // ICONO: Apoyo técnico
            // ============================================================
            "Apoyo técnico" -> {
                ground()

                // Cuerpo y uniforme de técnico.
                val jacket=Path().apply{
                    moveTo(w*.31f,h*.48f)
                    quadraticTo(w*.50f,h*.43f,w*.69f,h*.48f)
                    lineTo(w*.84f,h*.85f)
                    lineTo(w*.16f,h*.85f)
                    close()
                }
                drawPath(jacket,dark)

                val shirt=Path().apply{
                    moveTo(w*.37f,h*.49f)
                    lineTo(w*.63f,h*.49f)
                    lineTo(w*.74f,h*.85f)
                    lineTo(w*.26f,h*.85f)
                    close()
                }
                drawPath(shirt,Color(0xFF455761))

                // Bandas reflectivas.
                line(Color(0xFFDCE5E9),w*.21f,h*.68f,w*.79f,h*.68f,w*.045f)
                line(Color(0xFF90A0A8),w*.23f,h*.72f,w*.77f,h*.72f,w*.018f)

                // Brazos y guantes.
                line(dark,w*.34f,h*.54f,w*.18f,h*.78f,w*.092f)
                line(Color(0xFF65757E),w*.34f,h*.54f,w*.20f,h*.76f,w*.045f)
                line(dark,w*.66f,h*.54f,w*.82f,h*.78f,w*.092f)
                line(Color(0xFF65757E),w*.66f,h*.54f,w*.80f,h*.76f,w*.045f)
                circle(Color(0xFF252F35),w*.042f,w*.17f,h*.80f)
                circle(Color(0xFF252F35),w*.042f,w*.83f,h*.80f)

                // Cuello.
                rr(skinDark,w*.44f,h*.42f,w*.56f,h*.55f,w*.025f)
                rr(skin,w*.455f,h*.42f,w*.545f,h*.53f,w*.022f)

                // Cabeza.
                circle(skinDark,w*.135f,w*.50f,h*.34f)
                rr(skin,w*.405f,h*.29f,w*.595f,h*.49f,w*.060f)
                circle(skin,w*.025f,w*.39f,h*.37f)
                circle(skin,w*.025f,w*.61f,h*.37f)

                // Cabello.
                rr(Color(0xFF30363A),w*.41f,h*.285f,w*.59f,h*.34f,w*.025f)

                // Casco con visera.
                drawArc(
                    color=Color.White,
                    startAngle=180f,
                    sweepAngle=180f,
                    useCenter=true,
                    topLeft=androidx.compose.ui.geometry.Offset(w*.285f,h*.15f),
                    size=androidx.compose.ui.geometry.Size(w*.43f,h*.28f)
                )
                drawArc(
                    color=blueDark,
                    startAngle=180f,
                    sweepAngle=180f,
                    useCenter=true,
                    topLeft=androidx.compose.ui.geometry.Offset(w*.32f,h*.17f),
                    size=androidx.compose.ui.geometry.Size(w*.36f,h*.22f)
                )
                rr(Color.White,w*.29f,h*.285f,w*.71f,h*.34f,w*.025f)
                rr(blueDark,w*.25f,h*.31f,w*.75f,h*.36f,w*.028f)
                rr(blue,w*.30f,h*.31f,w*.70f,h*.345f,w*.018f)

                // Gafas y rostro.
                rr(Color(0xFF1E2930),w*.395f,h*.375f,w*.485f,h*.405f,w*.012f)
                rr(Color(0xFF1E2930),w*.515f,h*.375f,w*.605f,h*.405f,w*.012f)
                line(Color(0xFF303A40),w*.485f,h*.39f,w*.515f,h*.39f,w*.009f)
                line(skinDark,w*.49f,h*.41f,w*.50f,h*.43f,w*.006f)
                line(skinDark,w*.47f,h*.455f,w*.53f,h*.455f,w*.007f)

                // Radio y bolsillo.
                rr(dark2,w*.22f,h*.51f,w*.34f,h*.68f,w*.014f)
                rr(blue,w*.235f,h*.54f,w*.325f,h*.58f,w*.008f)
                line(Color(0xFF9AA9B0),w*.28f,h*.50f,w*.30f,h*.43f,w*.008f)
                rr(Color(0xFF26343D),w*.65f,h*.55f,w*.77f,h*.68f,w*.010f)
                rr(blue,w*.67f,h*.57f,w*.75f,h*.60f,w*.006f)

                // Distintivo del uniforme.
                rr(blue,w*.44f,h*.57f,w*.56f,h*.61f,w*.008f)
                rr(Color.White,w*.465f,h*.575f,w*.535f,h*.585f,w*.004f)
            }

            // ============================================================
            // ICONO: Herramientas / Otras
            // ============================================================
            "Herramientas", "Otras" -> {
                // ICONO DE REFERENCIA: se mantiene como el que te gustó.
                ground()
                rr(dark,w*.12f,h*.38f,w*.88f,h*.82f,w*.075f)
                rr(dark2,w*.15f,h*.40f,w*.85f,h*.80f,w*.055f)
                rr(blueDark,w*.13f,h*.34f,w*.87f,h*.47f,w*.045f)
                rr(blue,w*.16f,h*.36f,w*.84f,h*.44f,w*.025f)
                drawArc(color=dark,startAngle=180f,sweepAngle=180f,useCenter=false,topLeft=androidx.compose.ui.geometry.Offset(w*.34f,h*.18f),size=androidx.compose.ui.geometry.Size(w*.32f,h*.28f),style=Stroke(w*.055f))
                drawArc(color=Color(0xFF5A6870),startAngle=180f,sweepAngle=180f,useCenter=false,topLeft=androidx.compose.ui.geometry.Offset(w*.37f,h*.20f),size=androidx.compose.ui.geometry.Size(w*.26f,h*.22f),style=Stroke(w*.025f))
                line(aluminumDark,w*.28f,h*.43f,w*.39f,h*.20f,w*.055f)
                line(aluminum,w*.28f,h*.43f,w*.39f,h*.20f,w*.032f)
                rr(aluminumDark,w*.31f,h*.14f,w*.52f,h*.23f,w*.025f)
                rr(aluminum,w*.33f,h*.15f,w*.51f,h*.20f,w*.018f)
                line(yellowDark,w*.57f,h*.48f,w*.67f,h*.18f,w*.045f)
                line(yellow,w*.58f,h*.47f,w*.68f,h*.18f,w*.026f)
                rr(dark,w*.62f,h*.12f,w*.76f,h*.22f,w*.035f)
                rr(yellow,w*.64f,h*.13f,w*.74f,h*.20f,w*.022f)
                line(aluminumDark,w*.76f,h*.49f,w*.84f,h*.24f,w*.035f)
                line(aluminumDark,w*.83f,h*.49f,w*.75f,h*.24f,w*.035f)
                circle(blue,w*.035f,w*.795f,h*.495f)
                rr(Color(0xFF22282D),w*.23f,h*.55f,w*.43f,h*.74f,w*.025f)
                rr(Color(0xFF252B30),w*.47f,h*.55f,w*.77f,h*.74f,w*.025f)
                rr(yellowDark,w*.10f,h*.48f,w*.22f,h*.62f,w*.025f)
                rr(yellow,w*.12f,h*.49f,w*.20f,h*.58f,w*.015f)
                rr(yellowDark,w*.78f,h*.48f,w*.90f,h*.62f,w*.025f)
                rr(yellow,w*.80f,h*.49f,w*.88f,h*.58f,w*.015f)
            }

            else -> {
                circle(blue,w*.18f,w*.50f,h*.50f)
            }
        }
    }
}

@Composable
fun ResourceCard(option: ResourceOption, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(176.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, LineBlue),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            ResourceIcon(option.title, Modifier.size(118.dp, 112.dp))
            Spacer(Modifier.height(4.dp))
            Text(
                option.title,
                style = MaterialTheme.typography.titleSmall,
                color = TextMain,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun ToolsCard(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(176.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = NavyCard2),
        border = BorderStroke(1.dp, NeonBlue.copy(alpha = .55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            ResourceIcon("Herramientas", Modifier.size(118.dp, 112.dp))
            Spacer(Modifier.height(4.dp))
            Text("Herramientas", style = MaterialTheme.typography.titleSmall, color = TextMain)
        }
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.headlineSmall,
            color = TextMain,
            fontWeight = FontWeight.Black
        )
        subtitle?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSoft
            )
        }
    }
}

data class ResourceOption(val id: Long?, val title: String, val emoji: String)
data class Session(val token: String, val fullName: String)
data class Assistance(
    val id: String,
    val status: String,
    val resourceName: String?,
    val customResourceText: String?,
    val address: String?,
    val observation: String?,
    val requestedAt: String?,
    val driverName: String?,
    val driverPhone: String?,
    val plate: String?,
    val driverLat: Double?,
    val driverLng: Double?
)

data class RouteStop(
    val order: Int,
    val status: String,
    val technicianName: String,
    val resourceName: String?,
    val customResourceText: String?
)

data class DriverStatus(
    val id: String,
    val name: String,
    val status: String,
    val startedAt: String?,
    val lunchStartedAt: String?,
    val lunchEndedAt: String?,
    val note: String?,
    val statusAt: String?
)

data class RouteContext(
    val driverName: String?,
    val driverPhone: String?,
    val plate: String?,
    val yourOrder: Int,
    val stopsBeforeCount: Int,
    val totalPending: Int,
    val stopsBefore: List<RouteStop>,
    val driverLat: Double?,
    val driverLng: Double?,
    val batchStatus: String?
)

fun httpRequest(method: String, url: String, token: String? = null, body: String? = null): String {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        connectTimeout = 8000
        readTimeout = 10000
        setRequestProperty("Content-Type", "application/json")
        if (token != null) setRequestProperty("Authorization", "Bearer $token")
        doInput = true
        if (body != null) {
            doOutput = true
            outputStream.use { it.write(body.toByteArray()) }
        }
    }

    val code = connection.responseCode
    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
    val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
    connection.disconnect()

    if (code !in 200..299) {
        throw IllegalStateException(text.ifBlank { "Error HTTP $code" })
    }
    return text
}

private fun sendTechnicianLocation(
    session: Session,
    loc: Location,
    assistanceId: String?,
    executor: java.util.concurrent.Executor
) {
    // En DEMO no sale nada de la APK. En producción este POST alimenta al
    // backend, que distribuye la posición al conductor y al gestor.
    if (session.token.startsWith("DEMO_TECHNICIAN_")) return

    executor.execute {
        try {
            val body = JSONObject()
                .put("latitude", loc.latitude)
                .put("longitude", loc.longitude)
                .put("accuracy_m", loc.accuracy)
                .put("updated_at", System.currentTimeMillis())
            if (assistanceId != null) body.put("assistance_id", assistanceId)
            httpRequest("POST", "$API_BASE_URL/api/technician/location", session.token, body.toString())
        } catch (_: Exception) { }
    }
}

fun openDriverLocation(context: Context, lat: Double, lng: Double, label: String) {
    val geoUri = android.net.Uri.parse("geo:$lat,$lng?q=$lat,$lng(${android.net.Uri.encode(label)})")
    val geoIntent = Intent(Intent.ACTION_VIEW, geoUri)
    if (geoIntent.resolveActivity(context.packageManager) != null) {
        context.startActivity(geoIntent)
        return
    }

    // DEMO/Android: si no hay una app de mapas instalada, abre Google Maps en el navegador.
    val webUri = android.net.Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng")
    val webIntent = Intent(Intent.ACTION_VIEW, webUri)
    if (webIntent.resolveActivity(context.packageManager) != null) {
        context.startActivity(webIntent)
    }
}

private fun isGpsEnabled(context: Context): Boolean {
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        manager.isLocationEnabled
    } else {
        manager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
            manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }
}

@Composable
private fun TechnicianGpsGate(content: @Composable () -> Unit) {
    val context = LocalContext.current
    var gpsEnabled by remember { mutableStateOf(isGpsEnabled(context)) }
    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissionGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        gpsEnabled = isGpsEnabled(context)
    }

    LaunchedEffect(Unit) {
        while (true) {
            permissionGranted =
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            gpsEnabled = isGpsEnabled(context)
            delay(1000)
        }
    }

    if (!permissionGranted || !gpsEnabled) {
        Box(
            Modifier.fillMaxSize().background(DeepNavy),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(22.dp),
                shape = RoundedCornerShape(26.dp),
                color = NavyCard,
                border = BorderStroke(1.dp, LineBlue)
            ) {
                Column(
                    Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("GPS obligatorio", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text(
                        if (!permissionGranted)
                            "Para usar Asistencias Técnicas debes permitir el acceso a tu ubicación."
                        else
                            "Para usar Asistencias Técnicas debes mantener el GPS/ubicación activo."
                        ,
                        color = TextMain,
                        fontSize = 14.sp
                    )
                    if (!permissionGranted) {
                        Button(
                            onClick = {
                                permissionLauncher.launch(
                                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("PERMITIR UBICACIÓN") }
                    }
                    Button(
                        onClick = {
                            context.startActivity(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonBlue)
                    ) { Text("ACTIVAR GPS", color = Color.White, fontWeight = FontWeight.Black) }
                    Text(
                        "La aplicación permanecerá bloqueada mientras la ubicación esté desactivada.",
                        color = TextSoft,
                        fontSize = 12.sp
                    )
                }
            }
        }
    } else {
        content()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TechnicianApp() }
    }
}

@Composable
fun TechnicianApp() {
    TechnicianTheme {
    var session by remember { mutableStateOf<Session?>(null) }

    if (session == null) {
        LoginScreen(onLoggedIn = { session = it })
    } else {
        TechnicianGpsGate {
            TechnicianHome(session!!, onLogout = { session = null })
        }
    }
    }
}

@Composable
fun LoginScreen(onLoggedIn: (Session) -> Unit) {
    var cedula by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(DeepNavy, Color(0xFF071B32), Color(0xFF04101D)))
        )
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp).align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppMark(76.dp)
            Spacer(Modifier.height(18.dp))
            Text("ASISTENCIAS TÉCNICAS", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
            Text("PANEL DEL TÉCNICO", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(24.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = NavyCard,
                border = BorderStroke(1.dp, LineBlue)
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Iniciar sesión", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text("Ingresa con tus credenciales reales.", color = TextSoft, fontSize = 13.sp)
                    OutlinedTextField(
                        value = cedula,
                        onValueChange = { cedula = it.filter(Char::isDigit).take(20); error = null },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Cédula", color = TextSoft) }, singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan, unfocusedBorderColor = LineBlue,
                            focusedLabelColor = NeonCyan, unfocusedLabelColor = TextSoft,
                            focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = NeonCyan
                        )
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; error = null },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Contraseña", color = TextSoft) }, singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan, unfocusedBorderColor = LineBlue,
                            focusedLabelColor = NeonCyan, unfocusedLabelColor = TextSoft,
                            focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = NeonCyan
                        )
                    )
                    error?.let { Text(it, color = TechRed, fontSize = 12.sp) }
                    Button(
                        onClick = {
                            val cedulaValue = cedula.trim()
                            val passwordValue = password
                            loading = true
                            error = null
                            executor.execute {
                                try {
                                    val response = httpRequest(
                                        "POST", "$API_BASE_URL/api/auth/login",
                                        body = JSONObject().apply {
                                            put("cedula", cedulaValue)
                                            put("password", passwordValue)
                                        }.toString()
                                    )
                                    val json = JSONObject(response)
                                    val user = json.getJSONObject("user")
                                    val realSession = Session(
                                        token = json.getString("token"),
                                        fullName = user.optString("nombre").ifBlank { "Técnico" }
                                    )
                                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                                        loading = false
                                        onLoggedIn(realSession)
                                    }
                                } catch (e: Exception) {
                                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                                        loading = false
                                        error = e.message?.takeIf { it.isNotBlank() } ?: "No se pudo iniciar sesión"
                                    }
                                }
                            }
                        },
                        enabled = !loading && cedula.isNotBlank() && password.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonBlue, contentColor = Color.White)
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = TextMain, strokeWidth = 2.dp)
                        else Text("ENTRAR", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun TechnicianHome(session: Session, onLogout: () -> Unit) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("solicitar") }
    var showTools by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<ResourceOption?>(null) }
    var customText by remember { mutableStateOf("") }
    var observation by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var locationReady by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var resources by remember { mutableStateOf<List<ResourceOption>>(emptyList()) }
    var assistances by remember { mutableStateOf<List<Assistance>>(emptyList()) }
    var routeContext by remember { mutableStateOf<RouteContext?>(null) }
    var routeAssistanceId by remember { mutableStateOf<String?>(null) }
    var routeLoading by remember { mutableStateOf(false) }
    var driverStatuses by remember { mutableStateOf<List<DriverStatus>>(emptyList()) }
    var driverStatusUpdatedAt by remember { mutableStateOf<String?>(null) }
    var technicianLocationUpdatedAt by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var currentLocation by remember { mutableStateOf<Location?>(null) }
    var locating by remember { mutableStateOf(false) }
    // Regla de propiedad en la APK: esta lista contiene exclusivamente las
    // asistencias devueltas por /api/assistances/mine para el técnico autenticado.
    var ownAssistanceIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    val executor = remember { Executors.newSingleThreadExecutor() }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        locationReady = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    fun postToMain(action: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(action)
    }

    fun loadAssistances() {
        if (session.token.startsWith("DEMO_TECHNICIAN_")) {
            val demo = Assistance(
                id = "demo-assistance-${session.token.removePrefix("DEMO_TECHNICIAN_")}",
                status = "EN_CURSO",
                resourceName = "Escalera de extensión",
                customResourceText = null,
                address = "Dirección DEMO · destino del técnico",
                observation = "Seguimiento DEMO: el conductor viene en camino.",
                requestedAt = "Ahora · DEMO",
                driverName = "Carlos Demo",
                driverPhone = "300 000 0000",
                plate = "DEMO-123",
                driverLat = 4.7045,
                driverLng = -74.0750
            )
            assistances = listOf(demo)
            ownAssistanceIds = setOf(demo.id)
            loading = false
            message = null
            return
        }
        executor.execute {
            try {
                val arr = JSONArray(httpRequest("GET", "$API_BASE_URL/api/assistances/mine", session.token))
                val list = mutableListOf<Assistance>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list += Assistance(
                        id = o.getString("id"),
                        status = o.getString("status"),
                        resourceName = o.optString("resource_name").ifBlank { null },
                        customResourceText = o.optString("custom_resource_text").ifBlank { null },
                        address = o.optString("technician_address").ifBlank { null },
                        observation = o.optString("observation").ifBlank { null },
                        requestedAt = o.optString("requested_at").ifBlank { null },
                        driverName = o.optString("driver_name").ifBlank { null },
                        driverPhone = o.optString("driver_phone").ifBlank { null },
                        plate = o.optString("plate").ifBlank { null },
                        driverLat = if (o.isNull("driver_latitude")) null else o.getDouble("driver_latitude"),
                        driverLng = if (o.isNull("driver_longitude")) null else o.getDouble("driver_longitude")
                    )
                }
                postToMain {
                    assistances = list
                    ownAssistanceIds = list.map { it.id }.toSet()
                    loading = false
                }
            } catch (_: Exception) {
                postToMain {
                    loading = false
                    message = "No se pudieron cargar tus asistencias"
                }
            }
        }
    }

    fun loadDriverStatuses() {
        if (session.token.startsWith("DEMO_TECHNICIAN_")) {
            driverStatuses = listOf(
                DriverStatus("demo-driver-1", "Carlos Demo", "EN_CAMINO", "08:00", null, null, "Viene hacia tu asistencia", "Ahora"),
                DriverStatus("demo-driver-2", "Andrés Demo", "DISPONIBLE", "07:30", null, null, null, "Ahora"),
                DriverStatus("demo-driver-3", "Luis Demo", "EN_ASISTENCIA", "07:45", null, null, "Atendiendo otra solicitud", "Ahora")
            )
            driverStatusUpdatedAt = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            return
        }
        executor.execute {
            try {
                val arr = JSONArray(
                    httpRequest("GET", "$API_BASE_URL/api/locations/drivers/technician", session.token)
                )
                val list = mutableListOf<DriverStatus>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list += DriverStatus(
                        id = o.getString("id"),
                        name = o.getString("full_name"),
                        status = o.getString("status"),
                        startedAt = o.optString("started_at").ifBlank { null },
                        lunchStartedAt = o.optString("lunch_started_at").ifBlank { null },
                        lunchEndedAt = o.optString("lunch_ended_at").ifBlank { null },
                        note = o.optString("status_note").ifBlank { null },
                        statusAt = o.optString("status_at").ifBlank { null }
                    )
                }
                postToMain {
                    driverStatuses = list
                    driverStatusUpdatedAt = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                }
            } catch (_: Exception) {
                // Keep the previous list when the network is temporarily unavailable.
            }
        }
    }

    fun loadRouteContext(assistanceId: String) {
        routeLoading = true
        if (session.token.startsWith("DEMO_TECHNICIAN_") && assistanceId.startsWith("demo-assistance-")) {
            // Ruta DEMO instantánea: todos los datos están dentro de la APK.
            routeContext = RouteContext(
                driverName = "Carlos Demo",
                driverPhone = "300 000 0000",
                plate = "DEMO-123",
                yourOrder = 2,
                stopsBeforeCount = 1,
                totalPending = 2,
                stopsBefore = listOf(
                    RouteStop(1, "EN_CURSO", "Técnico Demo 2", "Herramientas", null)
                ),
                driverLat = 4.7045,
                driverLng = -74.0750,
                batchStatus = "EN_CAMINO"
            )
            routeLoading = false
            return
        }
        executor.execute {
            try {
                val o = JSONObject(
                    httpRequest("GET", "$API_BASE_URL/api/assistances/$assistanceId/route-context", session.token)
                )
                val driver = o.optJSONObject("driver")
                val arr = o.optJSONArray("stopsBefore") ?: JSONArray()
                val stops = mutableListOf<RouteStop>()

                for (i in 0 until arr.length()) {
                    val st = arr.getJSONObject(i)
                    stops += RouteStop(
                        order = st.optInt("stop_order"),
                        status = st.optString("status"),
                        technicianName = st.optString("technician_name"),
                        resourceName = st.optString("resource_name").ifBlank { null },
                        customResourceText = st.optString("custom_resource_text").ifBlank { null }
                    )
                }

                val driverLocation = o.optJSONObject("driverLocation")
                val ctx = RouteContext(
                    driverName = driver?.optString("name")?.ifBlank { null },
                    driverPhone = driver?.optString("phone")?.ifBlank { null },
                    plate = driver?.optString("plate")?.ifBlank { null },
                    yourOrder = o.optJSONObject("yourStop")?.optInt("order") ?: 0,
                    stopsBeforeCount = o.optInt("stopsBeforeCount"),
                    totalPending = o.optInt("totalPending"),
                    stopsBefore = stops,
                    driverLat = driverLocation?.let { if (it.has("latitude")) it.optDouble("latitude") else null },
                    driverLng = driverLocation?.let { if (it.has("longitude")) it.optDouble("longitude") else null },
                    batchStatus = o.optString("batchStatus").ifBlank { null }
                )
                postToMain {
                    routeContext = ctx
                    routeLoading = false
                }
            } catch (_: Exception) {
                postToMain {
                    routeLoading = false
                    routeContext = null
                }
            }
        }
    }

    fun requestCurrentLocation(onResult: (Location?) -> Unit) {
        val fineGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
            onResult(null)
            return
        }

        locating = true
        LocationServices.getFusedLocationProviderClient(context)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { loc ->
                locating = false
                currentLocation = loc
                locationReady = loc != null
                if (loc != null) {
                    technicianLocationUpdatedAt = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                    sendTechnicianLocation(session, loc, routeAssistanceId, executor)
                }
                onResult(loc)
            }
            .addOnFailureListener {
                locating = false
                locationReady = false
                onResult(null)
            }
    }

    LaunchedEffect(routeAssistanceId) {
        val id = routeAssistanceId ?: return@LaunchedEffect
        while (routeAssistanceId == id) {
            loadRouteContext(id)
            delay(4000)
        }
    }

    LaunchedEffect(Unit) {
        val fineGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted && !coarseGranted) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        } else {
            locationReady = true
        }

        executor.execute {
            // En modo DEMO no dependemos del backend para mostrar los recursos.
            // Esto evita que una API no disponible deje la pantalla vacía.
            if (session.token.startsWith("DEMO_TECHNICIAN_")) {
                val demoResources = listOf(
                    ResourceOption(1L, "Escalera de tijera", "🪜"),
                    ResourceOption(2L, "Escalera de extensión", "🪜"),
                    ResourceOption(3L, "Ambas", "🪜"),
                    ResourceOption(4L, "Auxiliar SENA", "👷"),
                    ResourceOption(5L, "Taladro", "🔧"),
                    ResourceOption(6L, "Portátil", "💻"),
                    ResourceOption(null, "Otras", "➕")
                )
                postToMain {
                    resources = demoResources
                    loading = false
                    message = null
                }
            } else {
                try {
                    val arr = JSONArray(httpRequest("GET", "$API_BASE_URL/api/resources", session.token))
                    val list = mutableListOf<ResourceOption>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val serverName = o.getString("name")
                        val name = serverName
                        val emoji = when (name) {
                            "Escalera de tijera", "Escalera de extensión", "Ambas" -> "🪜"
                            "Taladro" -> "🔧"
                            "Portátil" -> "💻"
                            "Auxiliar SENA" -> "👷"
                            else -> "➕"
                        }
                        list += ResourceOption(o.getLong("id"), name, emoji)
                    }
                    postToMain { resources = list }
                    loadAssistances()
                } catch (_: Exception) {
                    postToMain {
                        loading = false
                        message = "No se pudieron cargar los recursos"
                    }
                }
            }
        }
        }

    LaunchedEffect(Unit) {
        loadDriverStatuses()
        while (true) {
            delay(15000)
            loadDriverStatuses()
        }
    }

    // Ubicación del técnico: se publica cada 4 segundos y al mismo tiempo
    // se refresca la posición/estado de los conductores.
    LaunchedEffect(session.token) {
        while (true) {
            requestCurrentLocation { }
            if (!session.token.startsWith("DEMO_TECHNICIAN_")) {
                loadAssistances()
                loadDriverStatuses()
            }
            kotlinx.coroutines.delay(4000)
        }
    }

    // ============================================================
    // RECURSOS QUE SE MUESTRAN EN LA PANTALLA PRINCIPAL
    // ============================================================
    // Las 4 asistencias principales se muestran siempre.
    // Los IDs corresponden a los recursos reales del backend.
    val mainResources = listOf(
        ResourceOption(1L, "Escalera de tijera", "🪜"),
        ResourceOption(2L, "Escalera de extensión", "🪜"),
        ResourceOption(3L, "Ambas", "🪜"),
        ResourceOption(4L, "Auxiliar SENA", "👷")
    )

    // Estas aparecen únicamente cuando se pulsa "Herramientas".
    val tools = listOf(
        ResourceOption(null, "Taladro", "🔧"),
        ResourceOption(null, "Portátil", "💻"),
        ResourceOption(null, "Otras", "➕")
    )

    // Lista de solicitudes: permite llevar automáticamente el formulario a la vista
    // cuando el técnico selecciona una herramienta o recurso.
    val requestListState = rememberLazyListState()

    LaunchedEffect(selected) {
        if (selected != null) {
            delay(80)
            val lastIndex = requestListState.layoutInfo.totalItemsCount - 1
            if (lastIndex >= 0) {
                requestListState.animateScrollToItem(lastIndex)
            }
        }
    }

    Scaffold(
        containerColor = DeepNavy,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Navy)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppMark(38.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "Asistencias Técnicas",
                        color = TextMain,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        session.fullName,
                        color = TextMain.copy(alpha = .82f),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                IconButton(onClick = onLogout) {
                    Canvas(Modifier.size(24.dp)) {
                        drawCircle(
                            Color.White,
                            9f,
                            androidx.compose.ui.geometry.Offset(size.width * .38f, size.height * .50f),
                            style = Stroke(2.5f)
                        )
                        drawLine(
                            Color.White,
                            androidx.compose.ui.geometry.Offset(size.width * .50f, size.height * .50f),
                            androidx.compose.ui.geometry.Offset(size.width * .92f, size.height * .50f),
                            2.5f
                        )
                        drawLine(
                            Color.White,
                            androidx.compose.ui.geometry.Offset(size.width * .72f, size.height * .30f),
                            androidx.compose.ui.geometry.Offset(size.width * .92f, size.height * .50f),
                            2.5f
                        )
                        drawLine(
                            Color.White,
                            androidx.compose.ui.geometry.Offset(size.width * .72f, size.height * .70f),
                            androidx.compose.ui.geometry.Offset(size.width * .92f, size.height * .50f),
                            2.5f
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Navy, tonalElevation = 0.dp) {
                NavigationBarItem(
                    selected = screen == "solicitar",
                    onClick = { screen = "solicitar"; showTools = false; selected = null },
                    icon = { NavIcon("home", screen == "solicitar") },
                    label = { Text("Solicitar") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = NeonCyan, selectedTextColor = NeonCyan, unselectedIconColor = TextSoft, unselectedTextColor = TextSoft, indicatorColor = NavyCard2)
                )
                NavigationBarItem(
                    selected = screen == "mis",
                    onClick = { screen = "mis"; loadAssistances() },
                    icon = { NavIcon("list", screen == "mis") },
                    label = { Text("Mis asistencias") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = NeonCyan, selectedTextColor = NeonCyan, unselectedIconColor = TextSoft, unselectedTextColor = TextSoft, indicatorColor = NavyCard2)
                )
                NavigationBarItem(
                    selected = screen == "conductores",
                    onClick = { screen = "conductores"; loadDriverStatuses() },
                    icon = { NavIcon("car", screen == "conductores") },
                    label = { Text("Conductores") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = NeonCyan, selectedTextColor = NeonCyan, unselectedIconColor = TextSoft, unselectedTextColor = TextSoft, indicatorColor = NavyCard2)
                )
            }
        }
    ) { padding ->
        when (screen) {
            "mis" -> {
                LazyColumn(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp, vertical=14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { SectionTitle("Mis asistencias", "Consulta el estado de tus solicitudes y el conductor asignado.") }
                    if (loading) item { Box(Modifier.fillMaxWidth(), contentAlignment=Alignment.Center) { CircularProgressIndicator() } }
                    if (!loading && assistances.isEmpty()) item {
                        EmptyState("Sin asistencias", "Todavía no tienes solicitudes registradas.")
                    }
                    items(assistances) { a ->
                        ModernAssistanceCard(a, session, context, routeAssistanceId, routeLoading, routeContext, false,
                            onShowMap = {
                                if (a.driverLat != null && a.driverLng != null) {
                                    openDriverLocation(context, a.driverLat, a.driverLng, "Conductor DEMO · ${a.driverName ?: "Conductor"}")
                                }
                            },
                            onToggleRoute = {
                                routeAssistanceId = if (routeAssistanceId == a.id) null else a.id
                                routeContext = null
                                if (routeAssistanceId != null) loadRouteContext(a.id)
                            },
                            onCancel = {
                                // Un técnico solo puede cancelar asistencias que pertenezcan
                                // a su sesión y que hayan sido cargadas desde /mine.
                                if (a.id !in ownAssistanceIds) {
                                    message = "No autorizado: esta asistencia no pertenece a tu técnico."
                                } else if (session.token.startsWith("DEMO_TECHNICIAN_")) {
                                    // DEMO: cancelar es inmediato y no depende del backend.
                                    assistances = assistances.filterNot { it.id == a.id }
                                    routeAssistanceId = null
                                    routeContext = null
                                    message = "Asistencia cancelada correctamente"
                                } else {
                                    executor.execute {
                                        try {
                                            httpRequest("POST", "$API_BASE_URL/api/assistances/${a.id}/cancel", session.token, JSONObject().apply { put("reason", "Ya no necesita asistencia") }.toString())
                                            postToMain { message = "Asistencia cancelada"; loadAssistances() }
                                        } catch (_: Exception) { postToMain { message = "No se pudo cancelar" } }
                                    }
                                }
                            },
                            onCloseMap = { }
                        )
                    }
                    message?.let { item { MessageCard(it) } }
                }
            }
            "conductores" -> {
                LazyColumn(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp, vertical=14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { SectionTitle("Conductores", "Estado operativo actualizado automáticamente.") }
                    item { SmallInfoCard("Última actualización: ${driverStatusUpdatedAt ?: "cargando…"}") }
                    if (driverStatuses.isEmpty()) item { EmptyState("Sin conductores", "No hay conductores disponibles para consultar.") }
                    items(driverStatuses) { d -> DriverModernCard(d) }
                }
            }
            else -> {
                LazyColumn(
                    state = requestListState,
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp, vertical=14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            Modifier.fillMaxWidth(), shape=RoundedCornerShape(24.dp),
                            colors=CardDefaults.cardColors(containerColor=NavyCard),
                            elevation=CardDefaults.cardElevation(4.dp)
                        ) {
                            Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(NeonBlue, Color(0xFF0A4C9A), NeonCyan)))) {
                                Row(Modifier.padding(20.dp), verticalAlignment=Alignment.CenterVertically) {
                                    Box(Modifier.size(62.dp).clip(CircleShape).background(Color.White.copy(alpha=.16f)), contentAlignment=Alignment.Center) { AppMark(50.dp) }
                                    Spacer(Modifier.width(14.dp))
                                    Column {
                                        Text("Hola, ${session.fullName}", color=TextMain, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Black)
                                        Spacer(Modifier.height(3.dp))
                                        Text("Solicita apoyo técnico de forma rápida y sencilla.", color=TextSoft, style=MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                    item { SectionTitle("¿Qué necesitas?", "Selecciona el recurso o apoyo que deseas solicitar.") }
                    if (loading) {
                        item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment=Alignment.Center) { CircularProgressIndicator() } }
                    } else if (!showTools) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                // Pantalla principal: 4 recursos + Herramientas.
                                // "Otras" queda únicamente dentro de Herramientas.
                                mainResources.chunked(2).forEach { rowItems ->
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        rowItems.forEach { option ->
                                            Box(Modifier.weight(1f)) {
                                                ResourceCard(option) { selected = option }
                                            }
                                        }
                                        if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                                    }
                                }

                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(Modifier.weight(1f)) {
                                        ToolsCard {
                                            showTools = true
                                            selected = null
                                        }
                                    }
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    } else {
                        item {
                            Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=NavyCard), border=BorderStroke(1.dp, LineBlue), elevation=CardDefaults.cardElevation(2.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                                         Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) { Text("Herramientas", style=MaterialTheme.typography.titleLarge); Text("Selecciona una opción", style=MaterialTheme.typography.bodySmall, color=TextSoft) }
                                        TextButton(onClick={ showTools=false; selected=null; customText="" }) { Text("Volver") }
                                    }
                                    tools.chunked(2).forEach { rowItems ->
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                                            rowItems.forEach { option -> Box(Modifier.weight(1f)) { ResourceCard(option) { selected=option } } }
                                            if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                    selected?.let { option ->
                        item { ModernRequestForm(option, address, observation, customText, locating, locationReady, currentLocation, technicianLocationUpdatedAt,
                            onCustom={customText=it}, onAddress={address=it}, onObservation={observation=it}, onGps={
                                requestCurrentLocation { loc -> message = if (loc != null) "Ubicación actual obtenida" else "No se pudo obtener tu ubicación. Activa el GPS." }
                            }, onSubmit={
                                val custom = if (option.title == "Otras") customText.trim().ifBlank { null } else null
                                if (option.title == "Otras" && custom == null) {
                                    message = "Escribe qué herramienta necesitas."
                                } else if (address.isBlank() && currentLocation == null) {
                                    message = "Escribe una dirección o usa tu ubicación GPS."
                                } else {
                                    val requestBody = JSONObject().apply {
                                        if (option.id != null && option.title != "Otras") put("requestedResourceId", option.id)
                                        else put("requestedResourceId", JSONObject.NULL)
                                        put("customResourceText", custom ?: JSONObject.NULL)
                                        put("observation", observation.trim().ifBlank { JSONObject.NULL })
                                        put("technicianAddress", address.trim().ifBlank { JSONObject.NULL })
                                        currentLocation?.let {
                                            put("latitude", it.latitude)
                                            put("longitude", it.longitude)
                                        }
                                    }.toString()
                                    if (session.token.startsWith("DEMO_TECHNICIAN_")) {
                                        // DEMO local: crea la asistencia inmediatamente, sin backend ni tiempos de espera.
                                        val demoId = "demo-assistance-${System.currentTimeMillis()}"
                                        val demoLat = currentLocation?.latitude ?: 4.7045
                                        val demoLng = currentLocation?.longitude ?: -74.0750
                                        val demo = Assistance(
                                            id = demoId,
                                            status = "EN_CURSO",
                                            resourceName = option.title,
                                            customResourceText = custom,
                                            address = address.trim().ifBlank { "Dirección DEMO · destino del técnico" },
                                            observation = observation.trim().ifBlank { "Solicitud DEMO · conductor en camino." },
                                            requestedAt = "Ahora · DEMO",
                                            driverName = "Carlos Demo",
                                            driverPhone = "300 000 0000",
                                            plate = "DEMO-123",
                                            driverLat = demoLat,
                                            driverLng = demoLng
                                        )
                                        assistances = listOf(demo) + assistances.filterNot { it.id == demo.id }
                                            ownAssistanceIds = ownAssistanceIds + demo.id
                                        message = "Asistencia DEMO creada · conductor en camino"
                                        selected = null
                                        customText = ""
                                        observation = ""
                                        address = ""
                                        locationReady = false
                                        currentLocation = null
                                        screen = "asistencias"
                                    } else {
                                        executor.execute {
                                            try {
                                                httpRequest("POST", "$API_BASE_URL/api/assistances", session.token, requestBody)
                                                postToMain {
                                                    message = if (currentLocation != null) "Asistencia creada con dirección y ubicación GPS" else "Asistencia creada con la dirección"
                                                    selected = null
                                                    customText = ""
                                                    observation = ""
                                                    address = ""
                                                    locationReady = false
                                                    currentLocation = null
                                                    loadAssistances()
                                                }
                                            } catch (_: Exception) {
                                                postToMain { message = "No se pudo crear la asistencia" }
                                            }
                                        }
                                    }
                                }
                            }, onCancel={ selected=null; customText="" }) }
                    }
                    message?.let { item { MessageCard(it) } }
                }
            }
        }
    }
}


fun statusLabel(status: String): String = when (status) {
    "NUEVA" -> "Nueva · Buscando apoyo"
    "ACEPTADA" -> "Aceptada"
    "EN_CURSO" -> "En curso"
    "LLEGUE" -> "Llegó el conductor"
    "FINALIZADA" -> "Finalizada"
    "CANCELADA" -> "Cancelada"
    "REASIGNADA" -> "Reasignada"
    else -> status
}

fun driverStatusLabel(status: String): String = when (status) {
    "NO_INICIADO" -> "🟣 No ha iniciado jornada"
    "DISPONIBLE" -> "🟢 Disponible"
    "EN_CAMINO" -> "🟡 En camino"
    "EN_ASISTENCIA" -> "🔵 En asistencia"
    "EN_ALMUERZO" -> "🟠 En almuerzo"
    "FINALIZADO" -> "⚫ Jornada finalizada"
    "SIN_CONEXION" -> "🔴 Sin conexión"
    "AVERIA" -> "⚠️ Avería"
    else -> status
}


@Composable
fun NavIcon(kind: String, active: Boolean) {
    Canvas(Modifier.size(25.dp)) {
        val c = if (active) NeonCyan else TextSoft
        val w=size.width; val h=size.height
        when(kind){
            "home" -> { drawRoundRect(c, androidx.compose.ui.geometry.Offset(w*.18f,h*.40f), androidx.compose.ui.geometry.Size(w*.64f,h*.46f), androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()), style=Stroke(2.5f)); drawLine(c, androidx.compose.ui.geometry.Offset(w*.16f,h*.43f), androidx.compose.ui.geometry.Offset(w*.50f,h*.13f),2.5f); drawLine(c, androidx.compose.ui.geometry.Offset(w*.50f,h*.13f), androidx.compose.ui.geometry.Offset(w*.84f,h*.43f),2.5f); drawLine(c, androidx.compose.ui.geometry.Offset(w*.50f,h*.60f), androidx.compose.ui.geometry.Offset(w*.50f,h*.86f),2.5f) }
            "list" -> { for(i in 0..2){ val y=h*(.25f+i*.25f); drawCircle(c,2.5f,androidx.compose.ui.geometry.Offset(w*.18f,y)); drawLine(c,androidx.compose.ui.geometry.Offset(w*.32f,y),androidx.compose.ui.geometry.Offset(w*.82f,y),2.5f) } }
            else -> { drawCircle(c,5f,androidx.compose.ui.geometry.Offset(w*.50f,h*.34f)); drawRoundRect(c,androidx.compose.ui.geometry.Offset(w*.20f,h*.52f),androidx.compose.ui.geometry.Size(w*.60f,h*.30f),androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()), style=Stroke(2.5f)); drawCircle(c,2.8f,androidx.compose.ui.geometry.Offset(w*.33f,h*.84f)); drawCircle(c,2.8f,androidx.compose.ui.geometry.Offset(w*.67f,h*.84f)) }
        }
    }
}

@Composable
fun EmptyState(title: String, text: String) {
    Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=NavyCard), border=BorderStroke(1.dp, LineBlue), elevation=CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
             Spacer(Modifier.height(10.dp)); Text(title, style=MaterialTheme.typography.titleMedium); Text(text, style=MaterialTheme.typography.bodySmall, color=TextSoft)
        }
    }
}

@Composable
fun SmallInfoCard(text: String) { Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=NavyCard2), border=BorderStroke(1.dp, LineBlue)) { Text(text, Modifier.padding(14.dp), style=MaterialTheme.typography.bodySmall, color=TechBlueDark) } }
@Composable
fun MessageCard(text: String) { Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=NavyCard2), border=BorderStroke(1.dp, LineBlue)) { Text(text, Modifier.padding(14.dp), color=TextMain) } }

@Composable
fun DriverModernCard(d: DriverStatus) {
    val color = when(d.status){ "DISPONIBLE"->TechGreen; "EN_CAMINO"->Color(0xFFE0A11A); "EN_ASISTENCIA"->TechBlue; "SIN_CONEXION"->Color(0xFFE53935); "AVERIA"->Color(0xFFE53935); else->Color(0xFF607D8B) }
    Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=NavyCard), border=BorderStroke(1.dp, LineBlue), elevation=CardDefaults.cardElevation(3.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically){
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){ Text(d.name,style=MaterialTheme.typography.titleMedium); Text(driverStatusLabel(d.status),color=color,style=MaterialTheme.typography.labelLarge) }
            }
            when(d.status){
                "NO_INICIADO"->Text("Aún no ha iniciado jornada.")
                "DISPONIBLE"->Text("Jornada iniciada · Disponible para asistencia.")
                "EN_CAMINO"->Text("Está atendiendo una asistencia en ruta.")
                "EN_ASISTENCIA"->Text("Está atendiendo a otro técnico.")
                "EN_ALMUERZO"->Text("Está en almuerzo.")
                "FINALIZADO"->Text("Ya finalizó su jornada.")
                "SIN_CONEXION"->Text("Sin conexión reciente.")
                "AVERIA"->Text("Conductor/vehículo reportó una avería${d.note?.let { ": $it" } ?: "."}")
            }
            d.startedAt?.let{Text("Entrada: $it",style=MaterialTheme.typography.bodySmall,color=TextSoft)}
        }
    }
}

@Composable
fun ModernAssistanceCard(a: Assistance, session: Session, context: Context, routeAssistanceId: String?, routeLoading: Boolean, routeContext: RouteContext?, showDemoMap: Boolean, onShowMap:()->Unit, onToggleRoute:()->Unit, onCancel:()->Unit, onCloseMap:()->Unit){
    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=NavyCard), border=BorderStroke(1.dp, LineBlue),elevation=CardDefaults.cardElevation(3.dp)){
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){ Column(Modifier.weight(1f)){Text(a.resourceName ?: a.customResourceText ?: "Asistencia",style=MaterialTheme.typography.titleMedium); a.requestedAt?.let{Text(it,style=MaterialTheme.typography.bodySmall,color=TextSoft)}}; StatusPill(statusLabel(a.status)) }
            a.address?.let{ Text(it,style=MaterialTheme.typography.bodyMedium) }
            a.driverName?.let { driver -> Text("Conductor: $driver${a.plate?.let { plate -> " · $plate" } ?: ""}", style = MaterialTheme.typography.bodySmall) }
            a.observation?.let{Text("Observación: $it",style=MaterialTheme.typography.bodySmall)}
            if(a.driverLat!=null && a.driverLng!=null && a.status in listOf("ACEPTADA","EN_CURSO","LLEGUE")){
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=NavyCard2), border=BorderStroke(1.dp, LineBlue)){
                    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Ubicación del conductor",style=MaterialTheme.typography.titleSmall,color=TechBlueDark);Text("La posición se actualiza mientras el conductor está en ruta.",style=MaterialTheme.typography.bodySmall);Button(onClick=onShowMap,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("Ver ubicación")}}
                }
            } else if(a.status in listOf("ACEPTADA","EN_CURSO","LLEGUE")){ Text("Esperando ubicación del conductor…",style=MaterialTheme.typography.bodySmall,color=TextSoft) }
            if(a.status in listOf("ACEPTADA","EN_CURSO","LLEGUE")){
                OutlinedButton(onClick=onToggleRoute,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text(if(routeAssistanceId==a.id) "Ocultar ruta" else "Ver ruta y técnicos anteriores")}
                if(routeAssistanceId==a.id){ if(routeLoading) CircularProgressIndicator(Modifier.size(24.dp)); routeContext?.let{ctx->
                    Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        HorizontalDivider()
                        Text("Ruta del conductor", style=MaterialTheme.typography.titleMedium, color=TextMain)
                        Text(
                            "Conductor: ${ctx.driverName ?: "Sin asignar"}${ctx.plate?.let { " · $it" } ?: ""}",
                            style=MaterialTheme.typography.bodyMedium,
                            color=TextMain
                        )
                        ctx.driverPhone?.let {
                            Text("Teléfono: $it", style=MaterialTheme.typography.bodySmall, color=TextSoft)
                        }

                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = NeonBlueLight)
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Tu posición en la ruta", style = MaterialTheme.typography.labelLarge, color = TextMain)
                                Text("#${ctx.yourOrder}", style = MaterialTheme.typography.headlineMedium, color = TextMain)
                                Text(
                                    if (ctx.stopsBeforeCount == 0) "Eres el próximo destino"
                                    else "Hay ${ctx.stopsBeforeCount} técnico(s) antes que tú",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextMain
                                )
                            }
                        }

                        if (ctx.stopsBefore.isNotEmpty()) {
                            Text("Técnicos antes que tú", style = MaterialTheme.typography.titleSmall, color = TextMain)
                            ctx.stopsBefore.forEach { stop ->
                                Card(
                                    Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            Modifier.size(36.dp).clip(CircleShape).background(TechBlue),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                stop.order.toString(),
                                                color = TextMain,
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                stop.technicianName.ifBlank { "Técnico sin nombre" },
                                                style = MaterialTheme.typography.titleSmall,
                                                color = TextMain
                                            )
                                            Text(
                                                stop.resourceName ?: stop.customResourceText ?: "Asistencia",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextSoft
                                            )
                                            Text(
                                                statusLabel(stop.status),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = TechBlue
                                            )
                                        }
                                    }
                                }
                            }
                            Card(
                                Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = NavyCard2)
                            ) {
                                Text(
                                    if (ctx.stopsBeforeCount > 0) "Cuando se atiendan los técnicos anteriores, serás el próximo." else "Eres el próximo en la ruta.",
                                    Modifier.padding(12.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMain
                                )
                            }
                        }

                        Text("Paradas pendientes de la ruta: ${ctx.totalPending}", style = MaterialTheme.typography.bodySmall, color = TextSoft)
                        if(ctx.driverLat!=null&&ctx.driverLng!=null) OutlinedButton(onClick={openDriverLocation(context,ctx.driverLat,ctx.driverLng,ctx.driverName ?: "Conductor")},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("Abrir ubicación en Maps")} else Text("El conductor todavía no ha enviado ubicación.",style=MaterialTheme.typography.bodySmall)
                    }
                }}
            }
            if(a.status in listOf("NUEVA","ACEPTADA","EN_CURSO","LLEGUE") && (a.status != "EN_CURSO" || a.id.startsWith("demo-assistance-"))){ TextButton(onClick=onCancel){Text("Cancelar solicitud")}}
        }
    }
}

@Composable
fun StatusPill(text: String) { Surface(shape=RoundedCornerShape(50),color=TechBlueLight){Text(text,Modifier.padding(horizontal=10.dp,vertical=5.dp),color=TechBlueDark,style=MaterialTheme.typography.labelSmall)} }

@Composable
fun ModernRequestForm(option: ResourceOption,address:String,observation:String,customText:String,locating:Boolean,locationReady:Boolean,currentLocation:Location?,technicianLocationUpdatedAt:String?,onCustom:(String)->Unit,onAddress:(String)->Unit,onObservation:(String)->Unit,onGps:()->Unit,onSubmit:()->Unit,onCancel:()->Unit){
    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=NavyCard), border=BorderStroke(1.dp, LineBlue),elevation=CardDefaults.cardElevation(4.dp)){
        Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){ResourceIcon(option.title, Modifier.size(72.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("Nueva solicitud",style=MaterialTheme.typography.titleLarge);Text(option.title,style=MaterialTheme.typography.bodySmall,color=TechBlue)}}
            if(option.title=="Otras") OutlinedTextField(value=customText,onValueChange=onCustom,modifier=Modifier.fillMaxWidth(),label={Text("¿Qué necesitas?")},shape=RoundedCornerShape(14.dp),singleLine=true)
            OutlinedTextField(value=address,onValueChange=onAddress,modifier=Modifier.fillMaxWidth(),label={Text("Dirección de la asistencia")},placeholder={Text("Ej. Calle 45 # 20-30")},shape=RoundedCornerShape(14.dp))
            Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=NavyCard2), border=BorderStroke(1.dp, LineBlue)){
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Ubicación GPS",style=MaterialTheme.typography.titleSmall,color=TechBlueDark);Text(if(locationReady&&currentLocation!=null) (if(technicianLocationUpdatedAt!=null) "GPS listo · enviado $technicianLocationUpdatedAt · cada 4 s" else "GPS listo") else "Puedes enviar tu ubicación para facilitar la llegada",style=MaterialTheme.typography.bodySmall)};OutlinedButton(enabled=!locating,onClick=onGps,shape=RoundedCornerShape(12.dp)){Text(if(locating)"Obteniendo…" else "Usar GPS")}}
            }
            OutlinedTextField(value=observation,onValueChange=onObservation,modifier=Modifier.fillMaxWidth(),label={Text("Observación (opcional)")},shape=RoundedCornerShape(14.dp),minLines=2)
            Button(onClick=onSubmit,enabled=!locating,modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(16.dp)){Text("Solicitar asistencia",style=MaterialTheme.typography.titleMedium)}
            TextButton(onClick=onCancel,modifier=Modifier.fillMaxWidth()){Text("Cerrar")}
        }
    }
}

