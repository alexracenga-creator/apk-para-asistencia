@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "PROJECT_DIR=%~dp0"
set "GRADLE_VERSION=8.9"
set "FOUND_GRADLE="

for /d %%D in ("%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\*") do (
  if exist "%%~fD\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
    set "FOUND_GRADLE=%%~fD\gradle-%GRADLE_VERSION%\bin\gradle.bat"
  )
)

if defined FOUND_GRADLE (
  call "!FOUND_GRADLE!" %*
  exit /b %ERRORLEVEL%
)

echo.
echo No se encontro Gradle %GRADLE_VERSION% en la cache de Windows.
echo Abre el proyecto en Android Studio y deja que Gradle termine de sincronizar.
echo Despues vuelve a ejecutar este archivo.
echo.
exit /b 1
