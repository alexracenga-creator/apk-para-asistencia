# Asistencias Técnicas - APK Técnico

Proyecto Android Studio de la aplicación del técnico.

- Login real mediante cédula y validación contra el backend.
- Solicitud de asistencias y recursos.
- GPS del técnico.
- Mis asistencias y estados.
- Seguimiento de conductor y ubicación.
- Actualización periódica de información.
- Sin modo demo.

API base configurada en MainActivity.kt: http://10.0.2.2:3000

Abrir la carpeta `AsistenciasTecnicas_Tecnico_v2.0` desde Android Studio.

## Reglas implementadas en esta versión

### GPS obligatorio del técnico
- La aplicación bloquea el panel del técnico si la ubicación/GPS está desactivada.
- También bloquea el uso si no se concedió permiso de ubicación.
- El estado se comprueba continuamente y, al desactivar el GPS, vuelve a mostrar la pantalla de bloqueo.
- El técnico puede abrir directamente los ajustes de ubicación desde la aplicación.

### Cancelación de asistencias
- La APK mantiene un conjunto de IDs de asistencias propias, alimentado exclusivamente por `/api/assistances/mine`.
- La interfaz rechaza una cancelación cuyo ID no pertenezca a ese conjunto.
- La protección definitiva de autorización debe existir también en el endpoint `/api/assistances/{id}/cancel`: el backend debe comprobar que la asistencia pertenece al técnico autenticado y devolver 403 en caso contrario.
