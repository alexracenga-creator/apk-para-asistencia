# Regla de propiedad de asistencias — Técnico

- Cada técnico solo trabaja con las asistencias devueltas por `/api/assistances/mine` para su sesión.
- La APK mantiene `ownAssistanceIds` y rechaza desde la interfaz cualquier intento de cancelar un ID que no esté en ese conjunto.
- En DEMO, cada cédula (1–5) tiene un ID de asistencia propio (`demo-assistance-<cedula>`), por lo que otra cédula no comparte esa asistencia.
- Las nuevas asistencias DEMO se agregan también al conjunto de asistencias propias.
- La protección definitiva debe repetirse en el backend: el endpoint `POST /api/assistances/{id}/cancel` debe comprobar que la asistencia pertenece al técnico autenticado y devolver HTTP 403 si no pertenece.
