@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.asistencias.conductor

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

private const val API_BASE_URL = "http://192.168.1.215:3000"

// Paleta futurista: azul profundo + azul eléctrico + cian. No se usa morado.
private val NeonBlue = Color(0xFF1687FF)
private val NeonCyan = Color(0xFF00D9FF)
private val DeepNavy = Color(0xFF06111F)
private val Navy = Color(0xFF0A1B2E)
private val NavyCard = Color(0xFF10263D)
private val NavyCard2 = Color(0xFF132D47)
private val TextMain = Color(0xFFF4F9FF)
private val TextSoft = Color(0xFF9DB2C8)
private val TechGreen = Color(0xFF19D68A)
private val TechRed = Color(0xFFFF5C6C)
private val TechOrange = Color(0xFFFFA43B)
private val LineBlue = Color(0xFF23496C)
private const val DEMO_CEDULA = "12345"
private const val DEMO_TOKEN = "DEMO_CONDUCTOR"

private data class Session(val token: String, val fullName: String, val driverId: String? = null)
private data class Assignment(
    val id: String,
    val status: String,
    val technicianName: String?,
    val technicianPhone: String?,
    val resourceName: String?,
    val customResourceText: String?,
    val address: String?,
    val observation: String?,
    val requestedAt: String?,
    val latitude: Double?,
    val longitude: Double?,
    val stopOrder: Int?,
    val closedAt: String? = null,
    val cancellationReason: String? = null
)

private val DriverColors = lightColorScheme(
    primary = NeonBlue,
    onPrimary = Color.White,
    secondary = NeonCyan,
    background = DeepNavy,
    onBackground = TextMain,
    surface = NavyCard,
    onSurface = TextMain,
    surfaceVariant = NavyCard2,
    onSurfaceVariant = TextSoft
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DriverApp() }
    }
}

private fun isGpsEnabled(context: Context): Boolean {
    val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        locationManager.isLocationEnabled
    } else {
        try {
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        } catch (_: Exception) {
            false
        }
    }
}

@Composable
private fun GpsRequiredScreen(onOpenSettings: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(DeepNavy, Color(0xFF071B32), Color(0xFF04101D))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = NavyCard),
            border = BorderStroke(1.dp, NeonBlue.copy(alpha = .45f))
        ) {
            Column(
                modifier = Modifier.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .background(TechRed.copy(alpha = .12f), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.LocationOff,
                        contentDescription = null,
                        tint = TechRed,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Text(
                    "GPS requerido",
                    color = TextMain,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    "Para usar Tu Asistente debes mantener activada la ubicación del teléfono.",
                    color = TextSoft,
                    fontSize = 15.sp,
                    lineHeight = 22.sp
                )
                Text(
                    "La aplicación no permitirá ingresar al panel mientras el GPS esté apagado.",
                    color = NeonCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonBlue)
                ) {
                    Icon(Icons.Default.GpsFixed, null)
                    Spacer(Modifier.width(9.dp))
                    Text("Activar GPS", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DriverApp() {
    val context = LocalContext.current
    var session by remember { mutableStateOf<Session?>(null) }
    var gpsEnabled by remember { mutableStateOf(isGpsEnabled(context)) }

    // Se comprueba continuamente para bloquear el panel si el conductor apaga
    // la ubicación mientras la aplicación está abierta.
    LaunchedEffect(Unit) {
        while (true) {
            gpsEnabled = isGpsEnabled(context)
            kotlinx.coroutines.delay(1000)
        }
    }

    MaterialTheme(colorScheme = DriverColors) {
        if (!gpsEnabled) {
            GpsRequiredScreen(
                onOpenSettings = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    } catch (_: Exception) {
                    }
                }
            )
        } else if (session == null) {
            DriverLogin { session = it }
        } else {
            DriverHome(session!!){ session = null }
        }
    }
}

@Composable
private fun DriverLogin(onLoggedIn: (Session) -> Unit) {
    var cedula by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepNavy, Color(0xFF071B32), Color(0xFF04101D))))
    ) {
        // Luces de ambiente para darle profundidad sin imágenes externas.
        Box(
            Modifier
                .size(300.dp)
                .offset(x = 210.dp, y = (-70).dp)
                .background(NeonBlue.copy(alpha = .18f), RoundedCornerShape(180.dp))
        )
        Box(
            Modifier
                .size(240.dp)
                .offset(x = (-100).dp, y = 500.dp)
                .background(NeonCyan.copy(alpha = .10f), RoundedCornerShape(150.dp))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 34.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(62.dp)
                        .background(
                            Brush.linearGradient(listOf(NeonCyan, NeonBlue)),
                            RoundedCornerShape(20.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.LocationOn, null, tint = Color.White, modifier = Modifier.size(38.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("GPS", fontSize = 27.sp, fontWeight = FontWeight.Black, color = TextMain)
                    Text("ASISTENCIAS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonCyan, letterSpacing = 2.sp)
                }
            }

            Spacer(Modifier.height(34.dp))

            Text("CONTROL MÓVIL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonCyan, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text("Bienvenido, conductor", fontSize = 30.sp, fontWeight = FontWeight.Black, color = TextMain)
            Text("Gestiona tus asistencias y tu jornada desde un solo lugar.", fontSize = 14.sp, color = TextSoft, modifier = Modifier.padding(top = 7.dp))

            Spacer(Modifier.height(26.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = NavyCard.copy(alpha = .96f),
                border = BorderStroke(1.dp, LineBlue)
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Badge, null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(9.dp))
                        Text("ACCESO SEGURO", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSoft, letterSpacing = 1.2.sp)
                    }

                    OutlinedTextField(
                        value = cedula,
                        onValueChange = { cedula = it.filter(Char::isDigit) },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Número de cédula", color = TextSoft) },
                        leadingIcon = { Icon(Icons.Default.Person, null, tint = NeonCyan) },
                        singleLine = true,
                        shape = RoundedCornerShape(17.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = LineBlue,
                            focusedTextColor = TextMain,
                            unfocusedTextColor = TextMain,
                            cursorColor = NeonCyan,
                            focusedContainerColor = Color(0xFF0A1C30),
                            unfocusedContainerColor = Color(0xFF0A1C30)
                        )
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Contraseña", color = TextSoft) },
                        leadingIcon = { Icon(Icons.Default.Lock, null, tint = NeonCyan) },
                        singleLine = true,
                        shape = RoundedCornerShape(17.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = LineBlue,
                            focusedTextColor = TextMain,
                            unfocusedTextColor = TextMain,
                            cursorColor = NeonCyan,
                            focusedContainerColor = Color(0xFF0A1C30),
                            unfocusedContainerColor = Color(0xFF0A1C30)
                        )
                    )

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NeonBlue.copy(alpha = .12f),
                        border = BorderStroke(1.dp, NeonBlue.copy(alpha = .30f))
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).background(TechGreen, RoundedCornerShape(50)))
                            Spacer(Modifier.width(8.dp))
                            Text("Sistema operativo en línea", fontSize = 12.sp, color = TextSoft)
                        }
                    }

                    Button(
                        onClick = {
                            if (cedula.isBlank()) { error = "Ingresa la cédula"; return@Button }
                            if (password.isBlank()) { error = "Ingresa la contraseña"; return@Button }
                            loading = true
                            error = null
                            executor.execute {
                                try {
                                    val response = httpRequest("POST", "$API_BASE_URL/api/auth/login", null, JSONObject().put("cedula", cedula).put("password", password).toString())
                                    val json = JSONObject(response)
                                    val user = json.getJSONObject("user")
                                    val role = user.optString("role").ifBlank { user.optString("role_name") }
                                    if (role.isNotBlank() && role.uppercase() != "CONDUCTOR") throw Exception("Esta cédula no pertenece a un conductor")
                                    val s = Session(json.getString("token"), user.getString("nombre"), user.optString("id").ifBlank { null })
                                    Handler(Looper.getMainLooper()).post { loading = false; onLoggedIn(s) }
                                } catch (e: Exception) {
                                    Handler(Looper.getMainLooper()).post { loading = false; error = e.message ?: "No se pudo iniciar sesión" }
                                }
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(17.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonBlue)
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White)
                        else {
                            Icon(Icons.Default.ArrowForward, null)
                            Spacer(Modifier.width(9.dp))
                            Text("Entrar al panel", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    error?.let { Text(it, color = TechRed, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(NeonCyan, RoundedCornerShape(50)))
                Spacer(Modifier.width(7.dp))
                Text("GPS · Rutas · Asistencias · Jornada", fontSize = 11.sp, color = TextSoft)
            }
        }
    }
}

@Composable
private fun DriverHome(session: Session, onLogout: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var assignments by remember { mutableStateOf<List<Assignment>>(emptyList()) }
    var driverStatus by remember { mutableStateOf("NO_INICIADO") }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Assignment?>(null) }
    var cancellationTarget by remember { mutableStateOf<Assignment?>(null) }
    var showHistory by remember { mutableStateOf(false) }
    var currentLocation by remember { mutableStateOf<Location?>(null) }
    var locationReady by remember { mutableStateOf(false) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { p ->
        locationReady = p[Manifest.permission.ACCESS_FINE_LOCATION] == true || p[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    fun post(action: () -> Unit) = Handler(Looper.getMainLooper()).post(action)

    fun requestLocation() {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            return
        }
        LocationServices.getFusedLocationProviderClient(context)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { loc ->
                currentLocation = loc
                locationReady = loc != null
                if (loc != null) sendLocation(session, loc, selected?.id, executor)
            }
    }

    fun load() {
        loading = true
        if (session.token == DEMO_TOKEN) {
            assignments = listOf(
                Assignment("demo-1", "ACCEPTED", "Carlos Pérez", "300 555 0142", "Escalera de tijera", null, "Calle 72 # 45-18, Barranquilla", "Apoyo para instalación de servicio FTTH.", "Hoy 08:15", 10.9878, -74.7889, 1),
                Assignment("demo-2", "EN_CAMINO", "Laura Martínez", "301 555 0198", "Herramientas", null, "Carrera 53 # 80-45, Barranquilla", "Revisión y apoyo técnico.", "Hoy 09:05", 10.9972, -74.8074, 2),
                Assignment("demo-3", "NUEVA", "Andrés Gómez", "302 555 0117", null, "Taladro", "Calle 84 # 50-22, Barranquilla", "Se requiere taladro para trabajo en sitio.", "Hoy 10:20", 11.0042, -74.8171, 3)
            )
            driverStatus = "DISPONIBLE"
            loading = false
            return
        }
        executor.execute {
            try {
                val obj = JSONObject(httpRequest("GET", "$API_BASE_URL/api/driver/dashboard", session.token))
                val arr = obj.optJSONArray("assistances") ?: JSONArray()
                val list = mutableListOf<Assignment>()
                for (i in 0 until arr.length()) {
                    val a = arr.getJSONObject(i)
                    list += Assignment(
                        a.getString("id"),
                        a.optString("status"),
                        a.optString("technician_name").ifBlank { null },
                        a.optString("technician_phone").ifBlank { null },
                        a.optString("resource_name").ifBlank { null },
                        a.optString("custom_resource_text").ifBlank { null },
                        a.optString("technician_address").ifBlank { null },
                        a.optString("observation").ifBlank { null },
                        a.optString("requested_at").ifBlank { null },
                        if (a.isNull("technician_latitude")) null else a.optDouble("technician_latitude"),
                        if (a.isNull("technician_longitude")) null else a.optDouble("technician_longitude"),
                        if (a.has("stop_order")) a.optInt("stop_order") else null,
                        a.optString("completed_at").ifBlank { a.optString("cancelled_at").ifBlank { null } },
                        a.optString("cancellation_reason").ifBlank { a.optString("cancel_reason").ifBlank { null } }
                    )
                }
                post { assignments = list; driverStatus = obj.optString("driver_status", "NO_INICIADO"); loading = false }
            } catch (e: Exception) {
                post { loading = false; message = e.message ?: "No se pudieron cargar las asistencias" }
            }
        }
    }

    fun changeStatus(status: String) {
        if (session.token == DEMO_TOKEN) {
            driverStatus = status
            message = statusLabel(status)
            return
        }
        executor.execute {
            try {
                httpRequest("POST", "$API_BASE_URL/api/driver/status", session.token, JSONObject().put("status", status).toString())
                post { driverStatus = status; message = "Estado actualizado" }
            } catch (e: Exception) {
                post { message = e.message ?: "No se pudo actualizar el estado" }
            }
        }
    }

    fun changeAssignment(a: Assignment, status: String, reason: String? = null) {
        if (session.token == DEMO_TOKEN) {
            val closed = if (status in listOf("COMPLETADA", "FINALIZADA", "CANCELADA")) nowLabel() else null
            assignments = assignments.map {
                if (it.id == a.id) it.copy(status = status, closedAt = closed, cancellationReason = reason) else it
            }
            selected = null
            driverStatus = when (status) {
                "EN_ASISTENCIA" -> "EN_ASISTENCIA"
                "COMPLETADA", "FINALIZADA", "CANCELADA" -> "DISPONIBLE"
                else -> driverStatus
            }
            message = when (status) {
                "EN_CAMINO" -> "Desplazamiento iniciado"
                "EN_ASISTENCIA" -> "Llegada registrada · Conductor en asistencia"
                "COMPLETADA", "FINALIZADA" -> "Asistencia completada · Conductor disponible"
                "CANCELADA" -> "Asistencia cancelada · Conductor disponible"
                else -> "Asistencia actualizada"
            }
            return
        }
        executor.execute {
            try {
                val body = JSONObject().put("status", status)
                if (status == "CANCELADA" && !reason.isNullOrBlank()) {
                    body.put("reason", reason)
                    body.put("cancellation_reason", reason)
                }
                httpRequest("POST", "$API_BASE_URL/api/driver/assistances/${a.id}/status", session.token, body.toString())
                when (status) {
                    "EN_ASISTENCIA" -> httpRequest("POST", "$API_BASE_URL/api/driver/status", session.token, JSONObject().put("status", "EN_ASISTENCIA").toString())
                    "COMPLETADA", "FINALIZADA", "CANCELADA" -> httpRequest("POST", "$API_BASE_URL/api/driver/status", session.token, JSONObject().put("status", "DISPONIBLE").toString())
                }
                post {
                    selected = null
                    driverStatus = when (status) {
                        "EN_ASISTENCIA" -> "EN_ASISTENCIA"
                        "COMPLETADA", "FINALIZADA", "CANCELADA" -> "DISPONIBLE"
                        else -> driverStatus
                    }
                    message = when (status) {
                        "EN_CAMINO" -> "Desplazamiento iniciado"
                        "EN_ASISTENCIA" -> "Llegada registrada · Conductor en asistencia"
                        "COMPLETADA", "FINALIZADA" -> "Asistencia completada · Conductor disponible"
                        "CANCELADA" -> "Asistencia cancelada · Conductor disponible"
                        else -> "Asistencia actualizada"
                    }
                    load()
                }
            } catch (e: Exception) {
                post { message = e.message ?: "No se pudo actualizar la asistencia" }
            }
        }
    }

    LaunchedEffect(Unit) { requestLocation(); load() }
    LaunchedEffect(driverStatus) {
        if (driverStatus in listOf("DISPONIBLE", "EN_CAMINO", "EN_ASISTENCIA", "EN_ALMUERZO", "VEHICULO_VARADO", "OTRA_ACTIVIDAD")) {
            while (true) {
                kotlinx.coroutines.delay(15000)
                requestLocation()
            }
        }
    }

    Scaffold(
        containerColor = DeepNavy,
        topBar = {
            Surface(color = Color(0xFF071827), shadowElevation = 0.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(44.dp).background(Brush.linearGradient(listOf(NeonCyan, NeonBlue)), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.LocalShipping, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.widthIn(max = 240.dp)) {
                        Text("GPS ASISTENCIAS", fontSize = 15.sp, fontWeight = FontWeight.Black, color = TextMain, letterSpacing = .8.sp)
                        Text("Panel del conductor", fontSize = 11.sp, color = TextSoft)
                    }
                    Surface(shape = RoundedCornerShape(50), color = TechGreen.copy(alpha = .12f)) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).background(TechGreen, RoundedCornerShape(50)))
                            Spacer(Modifier.width(6.dp))
                            Text("ONLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TechGreen)
                        }
                    }
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "Salir", tint = TextSoft) }
                }
            }
        },
        bottomBar = {
            Surface(color = Color(0xFF071827), border = BorderStroke(1.dp, LineBlue)) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().height(76.dp), verticalAlignment = Alignment.CenterVertically) {
                    FuturisticBottomTab(tab == 0, Icons.Default.Assignment, "Asistencias") { tab = 0 }
                    FuturisticBottomTab(tab == 1, Icons.Default.Map, "Mapa") { tab = 1 }
                    FuturisticBottomTab(tab == 2, Icons.Default.DirectionsCar, "Jornada") { tab = 2 }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (tab == 0) {
                val activeAssignments = assignments.filter { it.status !in listOf("COMPLETADA", "FINALIZADA", "CANCELADA") }
                val historyAssignments = assignments.filter { it.status in listOf("COMPLETADA", "FINALIZADA", "CANCELADA") }
                item { HomeHeader(session.fullName, activeAssignments.size, loading) { load() } }
                if (loading) item { LoadingCard() }
                if (!loading && activeAssignments.isEmpty()) item { EmptyCard("No tienes asistencias pendientes") }
                items(activeAssignments, key = { it.id }) { a -> AssignmentCard(a) { selected = a } }
                item {
                    HistoryEntryCard(historyAssignments.size) { showHistory = true }
                }
            } else if (tab == 1) {
                item { DriverMapCard(currentLocation, locationReady) { requestLocation() } }
            } else {
                item { JourneyCard(driverStatus, currentLocation, locationReady, { requestLocation() }, { changeStatus(it) }) }
            }
            message?.let { msg -> item { MessageCard(msg) } }
        }
    }

    selected?.let { a ->
        AssignmentDetail(
            a = a,
            onClose = { selected = null },
            onMap = { openMap(context, a.latitude, a.longitude) },
            onStatus = { changeAssignment(a, it) },
            onCancelRequest = { cancellationTarget = a }
        )
    }

    cancellationTarget?.let { a ->
        CancellationDialog(
            assignment = a,
            onDismiss = { cancellationTarget = null },
            onConfirm = { reason ->
                cancellationTarget = null
                changeAssignment(a, "CANCELADA", reason)
            }
        )
    }

    if (showHistory) {
        HistoryDialog(
            assignments = assignments.filter { it.status in listOf("COMPLETADA", "FINALIZADA", "CANCELADA") },
            onDismiss = { showHistory = false }
        )
    }
}

@Composable
private fun FuturisticBottomTab(selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(0.33f).fillMaxHeight().clickable(onClick = onClick).padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (selected) NeonBlue.copy(alpha = .16f) else Color.Transparent,
            border = if (selected) BorderStroke(1.dp, NeonBlue.copy(alpha = .35f)) else null
        ) {
            Box(Modifier.padding(horizontal = 17.dp, vertical = 5.dp), contentAlignment = Alignment.Center) {
                Icon(icon, label, tint = if (selected) NeonCyan else TextSoft, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(label, color = if (selected) TextMain else TextSoft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HomeHeader(name: String, count: Int, loading: Boolean, onRefresh: () -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.widthIn(max = 240.dp)) {
                Text("CENTRO DE OPERACIONES", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonCyan, letterSpacing = 1.5.sp)
                Text("Hola, $name", fontSize = 27.sp, fontWeight = FontWeight.Black, color = TextMain)
                Text("Tu jornada, tus rutas, tus asistencias.", fontSize = 13.sp, color = TextSoft)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Actualizar", tint = NeonCyan) }
        }
        Spacer(Modifier.height(15.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            MiniMetric(
                "ASISTENCIAS",
                count.toString(),
                Icons.Default.Assignment,
                NeonBlue,
                Modifier.weight(1f)
            )
            MiniMetric(
                "ESTADO · GPS",
                if (loading) "..." else "ACTIVO · OK",
                Icons.Default.MyLocation,
                TechGreen,
                Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MiniMetric(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = NavyCard,
        border = BorderStroke(1.dp, LineBlue)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = .12f), RoundedCornerShape(11.dp)),
                Alignment.Center
            ) {
                Icon(icon, null, tint = color, modifier = Modifier.size(19.dp))
            }
            Spacer(Modifier.width(9.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    title,
                    fontSize = 9.sp,
                    color = TextSoft,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    value,
                    fontSize = 15.sp,
                    color = TextMain,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun LoadingCard() {
    Surface(shape = RoundedCornerShape(20.dp), color = NavyCard, border = BorderStroke(1.dp, LineBlue)) {
        Row(Modifier.fillMaxWidth().padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(25.dp), color = NeonCyan, strokeWidth = 3.dp)
            Spacer(Modifier.width(12.dp))
            Text("Sincronizando asistencias...", color = TextSoft, fontSize = 13.sp)
        }
    }
}

@Composable
private fun AssignmentCard(a: Assignment, onClick: () -> Unit) {
    val color = statusColor(a.status)
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(23.dp),
        color = NavyCard,
        border = BorderStroke(1.dp, if (a.status == "EN_CAMINO" || a.status == "EN_ASISTENCIA") color.copy(alpha = .55f) else LineBlue)
    ) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(50.dp).background(Brush.linearGradient(listOf(NeonBlue.copy(alpha = .28f), NeonCyan.copy(alpha = .12f))), RoundedCornerShape(16.dp)), Alignment.Center) {
                    Icon(resourceIcon(a), null, tint = NeonCyan, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.widthIn(max = 240.dp)) {
                    Text(a.resourceName ?: a.customResourceText ?: "Asistencia", fontSize = 20.sp, fontWeight = FontWeight.Black, color = TextMain)
                    a.stopOrder?.let { Text("PARADA $it", fontSize = 10.sp, color = NeonCyan, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
                }
                StatusPill(a.status)
            }
            a.technicianName?.let { InfoLine(Icons.Default.Person, "Técnico", it) }
            a.address?.let { InfoLine(Icons.Default.LocationOn, "Destino", it) }
            a.observation?.let { Text(it, fontSize = 12.sp, color = TextSoft, maxLines = 2) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ABRIR DETALLE", fontSize = 10.sp, color = NeonCyan, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Default.ChevronRight, null, tint = NeonCyan, modifier = Modifier.size(19.dp))
            }
        }
    }
}

@Composable
private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = NeonBlue, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(7.dp))
        Text("$title: ", fontSize = 12.sp, color = TextSoft, fontWeight = FontWeight.Bold)
        Text(value, fontSize = 13.sp, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 2)
    }
}

@Composable
private fun StatusPill(status: String) {
    val c = statusColor(status)
    Surface(shape = RoundedCornerShape(50), color = c.copy(alpha = .12f), border = BorderStroke(1.dp, c.copy(alpha = .30f))) {
        Text(statusLabel(status), Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Black, color = c)
    }
}

@Composable
private fun JourneyCard(status: String, location: Location?, ready: Boolean, onLocation: () -> Unit, onChangeStatus: (String) -> Unit) {
    var showStatusDialog by remember { mutableStateOf(false) }
    val currentColor = statusColor(status)

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(shape = RoundedCornerShape(25.dp), color = NavyCard, border = BorderStroke(1.dp, currentColor.copy(alpha = .35f))) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(57.dp).background(currentColor.copy(alpha = .12f), RoundedCornerShape(18.dp)), Alignment.Center) {
                        Icon(statusIcon(status), null, tint = currentColor, modifier = Modifier.size(29.dp))
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.widthIn(max = 240.dp)) {
                        Text("MI JORNADA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonCyan, letterSpacing = 1.4.sp)
                        Text(statusLabel(status), fontSize = 24.sp, fontWeight = FontWeight.Black, color = TextMain)
                    }
                }
                Surface(shape = RoundedCornerShape(17.dp), color = currentColor.copy(alpha = .08f), border = BorderStroke(1.dp, currentColor.copy(alpha = .25f))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).background(currentColor, RoundedCornerShape(50)))
                        Spacer(Modifier.width(9.dp))
                        Text("ESTADO OPERATIVO", fontSize = 11.sp, color = TextSoft, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Text(statusLabel(status), fontSize = 13.sp, color = currentColor, fontWeight = FontWeight.Black)
                    }
                }
                Button(
                    onClick = { showStatusDialog = true },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonBlue)
                ) {
                    Icon(Icons.Default.Tune, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Cambiar estado", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Surface(shape = RoundedCornerShape(23.dp), color = NavyCard, border = BorderStroke(1.dp, LineBlue)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MyLocation, null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.widthIn(max = 240.dp)) {
                        Text("GPS EN TIEMPO REAL", fontSize = 12.sp, fontWeight = FontWeight.Black, color = TextMain, letterSpacing = .8.sp)
                        Text(if (ready) "Ubicación disponible" else "Esperando autorización de ubicación", fontSize = 11.sp, color = TextSoft)
                    }
                    TextButton(onClick = onLocation) { Text("Actualizar", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
                Surface(shape = RoundedCornerShape(15.dp), color = if (ready) TechGreen.copy(alpha = .08f) else NeonBlue.copy(alpha = .08f)) {
                    Text(
                        if (ready) "● GPS ACTIVO · posición enviada automáticamente" else "● GPS PENDIENTE · toca Actualizar para activar",
                        Modifier.fillMaxWidth().padding(12.dp),
                        color = if (ready) TechGreen else NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                location?.let { Text("Lat %.6f   ·   Lng %.6f".format(it.latitude, it.longitude), fontSize = 11.sp, color = TextSoft) }
            }
        }
    }

    if (showStatusDialog) {
        AlertDialog(
            onDismissRequest = { showStatusDialog = false },
            containerColor = NavyCard,
            titleContentColor = TextMain,
            textContentColor = TextSoft,
            shape = RoundedCornerShape(27.dp),
            title = {
                Column {
                    Text("Estado de jornada", fontSize = 22.sp, fontWeight = FontWeight.Black, color = TextMain)
                    Text("Selecciona tu situación actual", fontSize = 12.sp, color = TextSoft)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    JourneyStatusButton("Disponible", "Listo para recibir asistencias", Icons.Default.CheckCircle, TechGreen, status == "DISPONIBLE") { showStatusDialog = false; onChangeStatus("DISPONIBLE") }
                    JourneyStatusButton("En almuerzo", "Pausa de alimentación", Icons.Default.Restaurant, TechOrange, status == "EN_ALMUERZO") { showStatusDialog = false; onChangeStatus("EN_ALMUERZO") }
                    JourneyStatusButton("Vehículo varado", "El vehículo presenta una falla", Icons.Default.Build, TechRed, status == "VEHICULO_VARADO") { showStatusDialog = false; onChangeStatus("VEHICULO_VARADO") }
                    JourneyStatusButton("Otra actividad", "Estoy realizando otra labor", Icons.Default.MoreHoriz, NeonBlue, status == "OTRA_ACTIVIDAD") { showStatusDialog = false; onChangeStatus("OTRA_ACTIVIDAD") }
                    JourneyStatusButton("Finalizar jornada", "Terminar la jornada de hoy", Icons.Default.StopCircle, TextSoft, status == "FINALIZADO") { showStatusDialog = false; onChangeStatus("FINALIZADO") }
                }
            },
            confirmButton = { TextButton(onClick = { showStatusDialog = false }) { Text("Cerrar", color = NeonCyan, fontWeight = FontWeight.Bold) } }
        )
    }
}

@Composable
private fun JourneyStatusButton(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) color.copy(alpha = .10f) else Color(0xFF0B2035),
        border = BorderStroke(1.dp, if (selected) color.copy(alpha = .45f) else LineBlue)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(43.dp).background(color.copy(alpha = .12f), RoundedCornerShape(13.dp)), Alignment.Center) { Icon(icon, null, tint = color, modifier = Modifier.size(21.dp)) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.widthIn(max = 240.dp)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.Black, color = if (selected) color else TextMain)
                Text(subtitle, fontSize = 11.sp, color = TextSoft)
            }
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = color, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun AssignmentDetail(
    a: Assignment,
    onClose: () -> Unit,
    onMap: () -> Unit,
    onStatus: (String) -> Unit,
    onCancelRequest: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = NavyCard,
        titleContentColor = TextMain,
        textContentColor = TextSoft,
        shape = RoundedCornerShape(27.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(NeonBlue.copy(alpha = .12f), RoundedCornerShape(14.dp)), Alignment.Center) { Icon(Icons.Default.Assignment, null, tint = NeonCyan) }
                Spacer(Modifier.width(11.dp))
                Column {
                    Text("DETALLE", fontSize = 10.sp, color = NeonCyan, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Text("Asistencia técnica", fontSize = 20.sp, color = TextMain, fontWeight = FontWeight.Black)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Text(a.resourceName ?: a.customResourceText ?: "Asistencia", fontSize = 24.sp, fontWeight = FontWeight.Black, color = TextMain)
                StatusPill(a.status)
                a.technicianName?.let { InfoLine(Icons.Default.Person, "Técnico", it) }
                a.technicianPhone?.let { InfoLine(Icons.Default.Phone, "Teléfono", it) }
                a.address?.let { InfoLine(Icons.Default.LocationOn, "Dirección", it) }
                a.observation?.let { Text(it, fontSize = 12.sp, color = TextSoft) }
                a.requestedAt?.let { Text("Solicitada: $it", fontSize = 11.sp, color = TextSoft) }
                if (a.latitude != null && a.longitude != null) {
                    OutlinedButton(onClick = onMap, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan), border = BorderStroke(1.dp, NeonBlue)) {
                        Icon(Icons.Default.Map, null)
                        Spacer(Modifier.width(7.dp))
                        Text("Ver ubicación", fontWeight = FontWeight.Bold)
                    }
                }
                when (a.status) {
                    "ACCEPTED", "NUEVA" -> ActionButton("Iniciar desplazamiento", Icons.Default.Navigation, NeonBlue) { onStatus("EN_CAMINO") }
                    "EN_CAMINO" -> ActionButton("Marcar llegada", Icons.Default.Place, NeonCyan) { onStatus("EN_ASISTENCIA") }
                    "EN_ASISTENCIA" -> {
                        ActionButton("Asistencia completada", Icons.Default.CheckCircle, TechGreen) { onStatus("COMPLETADA") }
                        OutlinedButton(onClick = onCancelRequest, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = TechRed), border = BorderStroke(1.dp, TechRed.copy(alpha = .5f))) {
                            Icon(Icons.Default.Cancel, null)
                            Spacer(Modifier.width(7.dp))
                            Text("Cancelar asistencia", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Cerrar", color = NeonCyan, fontWeight = FontWeight.Bold) } }
    )
}

@Composable
private fun HistoryEntryCard(count: Int, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(21.dp),
        color = NavyCard,
        border = BorderStroke(1.dp, LineBlue)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).background(NeonBlue.copy(alpha = .12f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.History, null, tint = NeonCyan, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.fillMaxWidth()) {
                Text("HISTORIAL DEL DÍA", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Text(
                    if (count == 0) "Todavía no has cerrado asistencias" else "$count asistencia${if (count == 1) "" else "s"} registrada${if (count == 1) "" else "s"}",
                    fontSize = 16.sp, color = TextMain, fontWeight = FontWeight.Black
                )
                Text("Ver dónde estuviste, horarios y cancelaciones", fontSize = 12.sp, color = TextSoft)
            }
            Icon(Icons.Default.ChevronRight, null, tint = NeonCyan)
        }
    }
}

@Composable
private fun HistoryDialog(assignments: List<Assignment>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavyCard,
        titleContentColor = TextMain,
        textContentColor = TextSoft,
        shape = RoundedCornerShape(27.dp),
        title = {
            Column {
                Text("ACTIVIDAD DEL DÍA", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text("Historial de asistencias", fontSize = 22.sp, color = TextMain, fontWeight = FontWeight.Black)
            }
        },
        text = {
            if (assignments.isEmpty()) {
                Text("Aún no hay asistencias completadas o canceladas hoy.", fontSize = 13.sp, color = TextSoft)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    assignments.forEach { a ->
                        Surface(
                            shape = RoundedCornerShape(17.dp),
                            color = DeepNavy,
                            border = BorderStroke(1.dp, LineBlue)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        a.resourceName ?: a.customResourceText ?: "Asistencia",
                                        modifier = Modifier.fillMaxWidth(0.68f),
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Black,
                                        color = TextMain
                                    )
                                    StatusPill(a.status)
                                }
                                a.technicianName?.let { Text("Técnico: $it", fontSize = 12.sp, color = TextSoft) }
                                a.address?.let { Text("📍 $it", fontSize = 12.sp, color = TextMain, fontWeight = FontWeight.SemiBold) }
                                a.requestedAt?.let { Text("Solicitada: $it", fontSize = 11.sp, color = TextSoft) }
                                a.closedAt?.let { Text("Cerrada: $it", fontSize = 11.sp, color = TextSoft) }
                                if (a.status == "CANCELADA") {
                                    Text(
                                        "Motivo: ${a.cancellationReason ?: "No registrado"}",
                                        fontSize = 12.sp,
                                        color = TechRed,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar", color = NeonCyan, fontWeight = FontWeight.Bold) } }
    )
}

@Composable
private fun CancellationDialog(assignment: Assignment, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var reason by remember(assignment.id) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavyCard,
        titleContentColor = TextMain,
        textContentColor = TextSoft,
        shape = RoundedCornerShape(27.dp),
        title = {
            Column {
                Text("CANCELAR ASISTENCIA", fontSize = 11.sp, color = TechRed, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("¿Por qué la cancelas?", fontSize = 22.sp, color = TextMain, fontWeight = FontWeight.Black)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    assignment.resourceName ?: assignment.customResourceText ?: "Asistencia",
                    fontSize = 15.sp,
                    color = TextMain,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Escribe el motivo", color = TextSoft) },
                    minLines = 3,
                    maxLines = 5,
                    shape = RoundedCornerShape(15.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TechRed,
                        unfocusedBorderColor = LineBlue,
                        focusedTextColor = TextMain,
                        unfocusedTextColor = TextMain,
                        cursorColor = TechRed,
                        focusedContainerColor = DeepNavy,
                        unfocusedContainerColor = DeepNavy
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (reason.trim().isNotEmpty()) onConfirm(reason.trim()) },
                enabled = reason.trim().isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = TechRed),
                shape = RoundedCornerShape(13.dp)
            ) { Text("Confirmar cancelación", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Volver", color = TextSoft, fontWeight = FontWeight.Bold) }
        }
    )
}

@Composable
private fun ActionButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(51.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = color)) {
        Icon(icon, null, tint = Color.White)
        Spacer(Modifier.width(7.dp))
        Text(text, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun DriverMapCard(location: Location?, ready: Boolean, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val lat = location?.latitude ?: 10.9878
    val lng = location?.longitude ?: -74.7889

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(25.dp),
        color = NavyCard,
        border = BorderStroke(1.dp, LineBlue)
    ) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(45.dp).background(NeonCyan.copy(alpha = .10f), RoundedCornerShape(14.dp)),
                    Alignment.Center
                ) {
                    Icon(Icons.Default.Map, null, tint = NeonCyan)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.fillMaxWidth()) {
                    Text("MAPA EN VIVO", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("Ubicación del conductor", fontSize = 20.sp, color = TextMain, fontWeight = FontWeight.Black)
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = DeepNavy,
                border = BorderStroke(1.dp, LineBlue)
            ) {
                Column(
                    Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.LocationOn, null, tint = NeonCyan, modifier = Modifier.size(58.dp))
                    Text("Ubicación actual", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text(
                        if (ready) "GPS activo · posición actual" else "GPS pendiente · ubicación de prueba",
                        color = if (ready) TechGreen else NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "LAT %.6f   ·   LNG %.6f".format(lat, lng),
                        color = TextSoft,
                        fontSize = 12.sp
                    )
                }
            }

            Button(
                onClick = onRefresh,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NavyCard2)
            ) {
                Icon(Icons.Default.MyLocation, null, tint = NeonCyan)
                Spacer(Modifier.width(8.dp))
                Text("Actualizar ubicación", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    val url = Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng")
                    val intent = Intent(Intent.ACTION_VIEW, url)
                    try {
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        // No cerrar la aplicación si el dispositivo no tiene navegador.
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonBlue)
            ) {
                Icon(Icons.Default.OpenInNew, null)
                Spacer(Modifier.width(8.dp))
                Text("Abrir mapa completo", fontSize = 15.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun EmptyCard(text: String) {
    Surface(shape = RoundedCornerShape(21.dp), color = NavyCard, border = BorderStroke(1.dp, LineBlue)) {
        Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.AssignmentLate, null, tint = TextSoft, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(9.dp))
            Text(text, color = TextSoft, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun MessageCard(text: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = NeonBlue.copy(alpha = .10f), border = BorderStroke(1.dp, NeonBlue.copy(alpha = .30f))) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, null, tint = NeonCyan, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(8.dp))
            Text(text, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun nowLabel(): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

private fun resourceIcon(a: Assignment) = when {
    a.resourceName?.contains("Escalera", true) == true -> Icons.Default.Construction
    a.resourceName?.contains("Taladro", true) == true -> Icons.Default.Build
    else -> Icons.Default.Handyman
}

private fun statusLabel(status: String) = when (status) {
    "NO_INICIADO" -> "Sin iniciar"
    "DISPONIBLE" -> "Disponible"
    "EN_CAMINO" -> "En camino"
    "EN_ASISTENCIA" -> "En asistencia"
    "EN_ALMUERZO" -> "En almuerzo"
    "VEHICULO_VARADO" -> "Vehículo varado"
    "OTRA_ACTIVIDAD" -> "Otra actividad"
    "FINALIZADO" -> "Finalizado"
    "ACCEPTED" -> "Aceptada"
    "NUEVA" -> "Nueva"
    "COMPLETADA", "FINALIZADA" -> "Completada"
    "CANCELADA" -> "Cancelada"
    else -> status
}

private fun statusColor(status: String) = when (status) {
    "DISPONIBLE", "COMPLETADA", "FINALIZADA" -> TechGreen
    "EN_CAMINO", "EN_ALMUERZO" -> TechOrange
    "EN_ASISTENCIA" -> NeonCyan
    "VEHICULO_VARADO", "CANCELADA" -> TechRed
    "OTRA_ACTIVIDAD" -> NeonBlue
    else -> NeonBlue
}

private fun statusIcon(status: String) = when (status) {
    "EN_ALMUERZO" -> Icons.Default.Restaurant
    "VEHICULO_VARADO" -> Icons.Default.Build
    "OTRA_ACTIVIDAD" -> Icons.Default.MoreHoriz
    "EN_ASISTENCIA" -> Icons.Default.Engineering
    "FINALIZADO" -> Icons.Default.StopCircle
    else -> Icons.Default.DirectionsCar
}

private fun openMap(context: Context, lat: Double?, lng: Double?) {
    if (lat == null || lng == null) return
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lng?q=$lat,$lng")))
}

private fun sendLocation(session: Session, loc: Location, assistanceId: String?, executor: java.util.concurrent.Executor) {
    if (session.token == DEMO_TOKEN) return
    executor.execute {
        try {
            val body = JSONObject().put("latitude", loc.latitude).put("longitude", loc.longitude).put("accuracy_m", loc.accuracy)
            if (assistanceId != null) body.put("assistance_id", assistanceId)
            httpRequest("POST", "$API_BASE_URL/api/driver/location", session.token, body.toString())
        } catch (_: Exception) { }
    }
}

private fun httpRequest(method: String, url: String, token: String? = null, body: String? = null): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.requestMethod = method
    c.connectTimeout = 10000
    c.readTimeout = 15000
    c.setRequestProperty("Accept", "application/json")
    if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
    if (body != null) {
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
    }
    val code = c.responseCode
    val stream = if (code in 200..299) c.inputStream else c.errorStream
    val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
    c.disconnect()
    if (code !in 200..299) throw Exception(JSONObject(text).optString("message").ifBlank { "Error HTTP $code" })
    return text
}
