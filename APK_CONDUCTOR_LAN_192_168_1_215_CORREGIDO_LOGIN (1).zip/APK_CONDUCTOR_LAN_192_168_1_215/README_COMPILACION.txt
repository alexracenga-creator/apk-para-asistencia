APK CONDUCTOR — LAN 192.168.1.215

1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle termine la sincronización.
3. Build > Make Project.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Instala la APK en el teléfono conectado a la misma Wi-Fi del PC.

Backend configurado:
http://192.168.1.215:3000

Login:
- Cédula
- Contraseña

IMPORTANTE:
- El PC debe mantener el backend ejecutándose en el puerto 3000.
- No subir .env, contraseñas ni secretos a GitHub.
